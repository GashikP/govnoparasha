import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  output: "standalone",
  appDir: './src/app',
  typescript: {
    ignoreBuildErrors: true,
  },
  reactStrictMode: false,
  eslint: {
    ignoreDuringBuilds: true,
  },
  images: {
    remotePatterns: [
      {
        protocol: 'https',
        hostname: 'images.unsplash.com',
      },
    ],
    domains: ['images.unsplash.com'],
  },
};

export default nextConfig;
