'use client'

import { Header } from '@/components/header'
import { Card, CardContent } from '@/components/ui/card'

export default function PrivacyPage() {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />

      <main className="flex-1 py-8 px-4 md:px-8">
        <div className="container mx-auto max-w-4xl">
          <h1 className="text-4xl font-bold mb-8">
            Политика конфиденциальности
          </h1>

          <Card>
            <CardContent className="p-8 space-y-6 prose prose dark:prose-invert max-w-none">
              <p className="text-lg leading-relaxed">
                Добро пожаловать в интернет-магазин Pshish («Магазин»). Мы уважаем вашу приватность и стремимся защитить личную информацию, которую вы предоставляете нам.
              </p>

              <section>
                <h2 className="text-2xl font-bold mb-4">1. Собираемая информация</h2>
                <p>
                  Мы собираем следующую информацию:
                </p>
                <ul>
                  <li><strong>Контактная информация:</strong> Имя, email, телефон, адрес доставки</li>
                  <li><strong>Информация о заказах:</strong> Состав заказа, способы оплаты и доставки, история заказов</li>
                  <li><strong>Техническая информация:</strong> IP-адрес, тип браузера, данные о посещении сайта</li>
                </ul>
              </section>

              <section>
                <h2 className="text-2xl font-bold mb-4">2. Цели сбора информации</h2>
                <p>
                  Мы используем собранную информацию для следующих целей:
                </p>
                <ul>
                  <li>Обработка и выполнение ваших заказов</li>
                  <li>Связь с вами по поводу заказа</li>
                  <li>Улучшение нашего сервиса и удобства использования сайта</li>
                  <li>Анализ посещаемости и улучшение контента</li>
                  <li>Предоставление вам новостей, акций и специальных предложений</li>
                </ul>
              </section>

              <section>
                <h2 className="text-2xl font-bold mb-4">3. Защита информации</h2>
                <p>
                  Мы принимаем все необходимые меры для защиты вашей информации:
                </p>
                <ul>
                  <li>Используем защищённое соединение HTTPS</li>
                  <li>Ограничиваем доступ к вашим данным авторизованным сотрудникам</li>
                  <li>Регулярно обновляем системы безопасности</li>
                  <li>Не передаём вашу информацию третьим лицам без вашего согласия</li>
                </ul>
              </section>

              <section>
                <h2 className="text-2xl font-bold mb-4">4. Использование куки</h2>
                <p>
                  Мы используем файлы куки (cookies) для улучшения вашего опыта:
                </p>
                <ul>
                  <li>Для авторизации и сохранения сессии</li>
                  <li>Для запоминания товаров в корзине</li>
                  <li>Для аналитики и улучшения работы сайта</li>
                </ul>
                <p className="mt-4">
                  Вы можете отключить куки в настройках браузера, но это может повлиять на работу сайта.
                </p>
              </section>

              <section>
                <h2 className="text-2xl font-bold mb-4">5. Передача третьим лицам</h2>
                <p>
                  Мы не передаём вашу личную информацию третьим лицам за исключением следующих случаев:
                </p>
                <ul>
                  <li>Для доставки заказа (служба доставки СДЭК)</li>
                  <li>Для обработки оплаты (платёжные системы)</li>
                  <li>При получении вашего явного согласия</li>
                  <li>По требованию законодательства (судебным органам и т.д.)</li>
                </ul>
              </section>

              <section>
                <h2 className="text-2xl font-bold mb-4">6. Ваши права</h2>
                <p>
                  У вас есть следующие права в отношении вашей информации:
                </p>
                <ul>
                  <li><strong>Доступ к информации:</strong> Вы можете просматривать и редактировать свои данные в личном кабинете</li>
                  <li><strong>Удаление аккаунта:</strong> Вы можете запросить удаление вашего аккаунта и всей связанной информации</li>
                  <li><strong>Отзыв от подписки:</strong> Вы можете отказаться от получения маркетинговых писем</li>
                  <li><strong>Исправление информации:</strong> Вы можете обновлять свои данные в любое время</li>
                </ul>
              </section>

              <section>
                <h2 className="text-2xl font-bold mb-4">7. Контакты</h2>
                <p>
                  Если у вас есть вопросы или предложения по поводу нашей политики конфиденциальности, пожалуйста, свяжитесь с нами:
                </p>
                <ul>
                  <li>Email: @loomanager</li>
                  <li>Telegram: @loomanager</li>
                  <li>Телефон: 8 (950) 828-02-13</li>
                </ul>
              </section>

              <section className="mt-8 pt-8 border-t">
                <p className="text-sm text-muted-foreground">
                  Эта политика конфиденциальности была последней раз обновлена:{' '}
                  {new Date().toLocaleDateString('ru-RU', {
                    day: 'numeric',
                    month: 'long',
                    year: 'numeric',
                  })}
                </p>
                <p className="text-sm text-muted-foreground mt-2">
                  Мы оставляем за собой право изменять эту политику в любое время. Любые изменения будут опубликованы на этой странице.
                </p>
              </section>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  )
}
