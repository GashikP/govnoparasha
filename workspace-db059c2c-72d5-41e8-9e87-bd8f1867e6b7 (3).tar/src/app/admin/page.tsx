'use client'

import { useEffect, useState } from 'react'
import { Header } from '@/components/header'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Badge } from '@/components/ui/badge'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Switch } from '@/components/ui/switch'
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import {
  Package,
  ShoppingCart,
  TrendingUp,
  AlertCircle,
  Plus,
  Edit,
  Trash2,
  X,
  Upload,
  FileText,
  Tag,
} from 'lucide-react'
import { toast } from 'sonner'

interface Stats {
  totalOrders: number
  totalRevenue: number
  ordersByStatus: { status: string; _count: { status: number } }[]
  recentOrders: any[]
  totalProducts: number
  lowStockProducts: any[]
}

interface Product {
  id: string
  name: string
  price: number
  style: string
  category: { name: string }
  isActive: boolean
  isFeatured: boolean
}

interface PromoCode {
  id: string
  code: string
  discount: number
  type: 'percentage' | 'fixed'
  minAmount: number | null
  maxUses: number | null
  usedCount: number
  validFrom: string | null
  validUntil: string | null
  isActive: boolean
}

interface BlogPost {
  id: string
  title: string
  slug: string
  isPublished: boolean
  createdAt: string
}

export default function AdminPage() {
  const [stats, setStats] = useState<Stats | null>(null)
  const [products, setProducts] = useState<Product[]>([])
  const [categories, setCategories] = useState<any[]>([])
  const [promoCodes, setPromoCodes] = useState<PromoCode[]>([])
  const [blogPosts, setBlogPosts] = useState<BlogPost[]>([])
  const [loading, setLoading] = useState(true)

  // Product form state
  const [showProductForm, setShowProductForm] = useState(false)
  const [productForm, setProductForm] = useState({
    name: '',
    slug: '',
    description: '',
    price: '',
    oldPrice: '',
    categoryId: '',
    style: 'normal',
    isFeatured: false,
    isActive: true,
    variants: [{ size: '', color: '', stock: '' }],
    images: [{ url: '', alt: '' }],
  })
  const [uploading, setUploading] = useState(false)

  useEffect(() => {
    fetchData()
  }, [])

  const fetchData = async () => {
    try {
      const [statsRes, productsRes, categoriesRes, promosRes, blogRes] = await Promise.all([
        fetch('/api/admin/stats'),
        fetch('/api/admin/products'),
        fetch('/api/categories'),
        fetch('/api/promocodes'),
        fetch('/api/blog'),
      ])

      const [statsData, productsData, categoriesData, promosData, blogData] = await Promise.all([
        statsRes.json(),
        productsRes.json(),
        categoriesRes.json(),
        promosRes.json(),
        blogRes.json(),
      ])

      setStats(statsData)
      setProducts(productsData)
      setCategories(categoriesData)
      setPromoCodes(promosData)
      setBlogPosts(blogData)
    } catch (error) {
      console.error('Error fetching data:', error)
    } finally {
      setLoading(false)
    }
  }

  const formatPrice = (price: number) => {
    return price.toLocaleString('ru-RU', {
      style: 'currency',
      currency: 'RUB',
    })
  }

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>, index: number) => {
    const file = e.target.files?.[0]
    if (!file) return

    // Convert to base64 for demo (in production, upload to server)
    const reader = new FileReader()
    reader.onloadend = () => {
      const newImages = [...productForm.images]
      newImages[index].url = reader.result as string
      setProductForm({ ...productForm, images: newImages })
    }
    reader.readAsDataURL(file)
  }

  const handleAddProduct = async (e: React.FormEvent) => {
    e.preventDefault()
    setUploading(true)

    try {
      const payload = {
        name: productForm.name,
        slug: productForm.slug || productForm.name.toLowerCase().replace(/\s+/g, '-'),
        description: productForm.description || null,
        price: parseFloat(productForm.price),
        ...(productForm.oldPrice && { oldPrice: parseFloat(productForm.oldPrice) }),
        categoryId: productForm.categoryId,
        style: productForm.style,
        isFeatured: productForm.isFeatured,
        variants: productForm.variants
          .filter((v) => v.size || v.color || v.stock)
          .map((v) => ({
            ...(v.size && { size: v.size }),
            ...(v.color && { color: v.color }),
            stock: parseInt(v.stock) || 0,
          })),
        images: productForm.images.filter((i) => i.url).map((i, idx) => ({
          url: i.url,
          alt: i.alt || productForm.name,
          order: idx,
        })),
      }

      const response = await fetch('/api/admin/products', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(payload),
      })

      if (!response.ok) {
        throw new Error('Failed to create product')
      }

      toast.success('Товар добавлен!')
      setShowProductForm(false)
      resetProductForm()
      fetchData()
    } catch (error) {
      console.error('Error creating product:', error)
      toast.error('Ошибка при добавлении товара')
    } finally {
      setUploading(false)
    }
  }

  const resetProductForm = () => {
    setProductForm({
      name: '',
      slug: '',
      description: '',
      price: '',
      oldPrice: '',
      categoryId: '',
      style: 'normal',
      isFeatured: false,
      isActive: true,
      variants: [{ size: '', color: '', stock: '' }],
      images: [{ url: '', alt: '' }],
    })
  }

  const handleAddVariant = () => {
    setProductForm({
      ...productForm,
      variants: [...productForm.variants, { size: '', color: '', stock: '' }],
    })
  }

  const handleRemoveVariant = (index: number) => {
    setProductForm({
      ...productForm,
      variants: productForm.variants.filter((_, i) => i !== index),
    })
  }

  const handleAddImage = () => {
    setProductForm({
      ...productForm,
      images: [...productForm.images, { url: '', alt: '' }],
    })
  }

  const handleRemoveImage = (index: number) => {
    setProductForm({
      ...productForm,
      images: productForm.images.filter((_, i) => i !== index),
    })
  }

  const handleDeleteProduct = async (productId: string) => {
    if (!confirm('Вы уверены, что хотите удалить этот товар?')) {
      return
    }

    try {
      const response = await fetch(`/api/admin/products/${productId}`, {
        method: 'DELETE',
      })

      if (!response.ok) {
        throw new Error('Failed to delete product')
      }

      toast.success('Товар удалён')
      fetchData()
    } catch (error) {
      console.error('Error deleting product:', error)
      toast.error('Ошибка при удалении товара')
    }
  }

  const handleDeletePromoCode = async (id: string) => {
    if (!confirm('Вы уверены, что хотите удалить этот промокод?')) {
      return
    }

    try {
      const response = await fetch(`/api/promocodes/${id}`, {
        method: 'DELETE',
      })

      if (!response.ok) {
        throw new Error('Failed to delete promo code')
      }

      toast.success('Промокод удалён')
      fetchData()
    } catch (error) {
      console.error('Error deleting promo code:', error)
      toast.error('Ошибка при удалении промокода')
    }
  }

  const handleDeleteBlogPost = async (slug: string) => {
    if (!confirm('Вы уверены, что хотите удалить этот пост?')) {
      return
    }

    try {
      const response = await fetch(`/api/blog/${slug}`, {
        method: 'DELETE',
      })

      if (!response.ok) {
        throw new Error('Failed to delete blog post')
      }

      toast.success('Пост удалён')
      fetchData()
    } catch (error) {
      console.error('Error deleting blog post:', error)
      toast.error('Ошибка при удалении поста')
    }
  }

  const getStatusColor = (status: string) => {
    const colors: Record<string, string> = {
      pending: 'bg-yellow-500',
      paid: 'bg-blue-500',
      processing: 'bg-purple-500',
      shipped: 'bg-cyan-500',
      delivered: 'bg-green-500',
      cancelled: 'bg-red-500',
    }
    return colors[status] || 'bg-gray-500'
  }

  const getStatusLabel = (status: string) => {
    const labels: Record<string, string> = {
      pending: 'Ожидает оплаты',
      paid: 'Оплачен',
      processing: 'В обработке',
      shipped: 'Отправлен',
      delivered: 'Доставлен',
      cancelled: 'Отменён',
    }
    return labels[status] || status
  }

  if (loading) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        <main className="flex-1 flex items-center justify-center">
          <div className="text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
            <p>Загрузка...</p>
          </div>
        </main>
      </div>
    )
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Header />

      <main className="flex-1 py-8 px-4 md:px-8">
        <div className="container mx-auto max-w-7xl">
          <div className="flex justify-between items-center mb-8">
            <h1 className="text-3xl font-bold">Админ-панель</h1>
          </div>

          <Tabs defaultValue="dashboard" className="space-y-6">
            <TabsList className="grid w-full grid-cols-5">
              <TabsTrigger value="dashboard">Дашборд</TabsTrigger>
              <TabsTrigger value="orders">Заказы</TabsTrigger>
              <TabsTrigger value="products">Товары</TabsTrigger>
              <TabsTrigger value="promos">Промокоды</TabsTrigger>
              <TabsTrigger value="blog">Блог</TabsTrigger>
            </TabsList>

            {/* Dashboard Tab */}
            <TabsContent value="dashboard" className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">
                      Всего заказов
                    </CardTitle>
                    <ShoppingCart className="h-4 w-4 text-muted-foreground" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">{stats?.totalOrders || 0}</div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">
                      Выручка
                    </CardTitle>
                    <TrendingUp className="h-4 w-4 text-muted-foreground" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">
                      {formatPrice(stats?.totalRevenue || 0)}
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">
                      Товаров
                    </CardTitle>
                    <Package className="h-4 w-4 text-muted-foreground" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">
                      {stats?.totalProducts || 0}
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">
                      Мало на складе
                    </CardTitle>
                    <AlertCircle className="h-4 w-4 text-muted-foreground" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold text-orange-500">
                      {stats?.lowStockProducts?.length || 0}
                    </div>
                  </CardContent>
                </Card>
              </div>

              <Card>
                <CardHeader>
                  <CardTitle>Последние заказы</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {stats?.recentOrders?.length === 0 ? (
                      <p className="text-center text-muted-foreground py-8">
                        Заказов пока нет
                      </p>
                    ) : (
                      stats?.recentOrders?.slice(0, 5).map((order: any) => (
                        <div
                          key={order.id}
                          className="flex items-center justify-between p-4 border rounded-lg"
                        >
                          <div>
                            <div className="font-medium">{order.orderNumber}</div>
                            <div className="text-sm text-muted-foreground">
                              {order.customerName}
                            </div>
                          </div>
                          <div className="flex items-center gap-4">
                            <Badge className={getStatusColor(order.status)}>
                              {getStatusLabel(order.status)}
                            </Badge>
                            <span className="font-semibold">
                              {formatPrice(order.totalAmount)}
                            </span>
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Products Tab */}
            <TabsContent value="products">
              <div className="space-y-6">
                <div className="flex justify-end">
                  <Dialog open={showProductForm} onOpenChange={setShowProductForm}>
                    <DialogTrigger asChild>
                      <Button>
                        <Plus className="mr-2 h-4 w-4" />
                        Добавить товар
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
                      <DialogHeader>
                        <DialogTitle>Добавить новый товар</DialogTitle>
                      </DialogHeader>
                      <form onSubmit={handleAddProduct} className="space-y-6">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div className="space-y-2">
                            <Label htmlFor="name">Название *</Label>
                            <Input
                              id="name"
                              value={productForm.name}
                              onChange={(e) => setProductForm({ ...productForm, name: e.target.value })}
                              placeholder="Название товара"
                              required
                            />
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor="slug">Slug</Label>
                            <Input
                              id="slug"
                              value={productForm.slug}
                              onChange={(e) => setProductForm({ ...productForm, slug: e.target.value })}
                              placeholder="url-адрес товара"
                            />
                          </div>
                        </div>

                        <div className="space-y-2">
                          <Label htmlFor="description">Описание</Label>
                          <Textarea
                            id="description"
                            value={productForm.description}
                            onChange={(e) => setProductForm({ ...productForm, description: e.target.value })}
                            placeholder="Описание товара..."
                            rows={4}
                          />
                        </div>

                        <div className="space-y-2">
                          <Label htmlFor="category">Категория *</Label>
                          <select
                            id="category"
                            className="w-full p-2 border rounded-md"
                            value={productForm.categoryId}
                            onChange={(e) => setProductForm({ ...productForm, categoryId: e.target.value })}
                            required
                          >
                            <option value="">Выберите категорию</option>
                            {categories.map((cat) => (
                              <option key={cat.id} value={cat.id}>
                                {cat.name}
                              </option>
                            ))}
                          </select>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div className="space-y-2">
                            <Label htmlFor="price">Цена *</Label>
                            <Input
                              id="price"
                              type="number"
                              value={productForm.price}
                              onChange={(e) => setProductForm({ ...productForm, price: e.target.value })}
                              placeholder="1500"
                              required
                            />
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor="oldPrice">Старая цена</Label>
                            <Input
                              id="oldPrice"
                              type="number"
                              value={productForm.oldPrice}
                              onChange={(e) => setProductForm({ ...productForm, oldPrice: e.target.value })}
                              placeholder="2000"
                            />
                          </div>
                        </div>

                        <div className="space-y-2">
                          <Label>Стиль *</Label>
                          <RadioGroup
                            value={productForm.style}
                            onValueChange={(value) => setProductForm({ ...productForm, style: value as any })}
                          >
                            <div className="flex flex-wrap gap-4">
                              {[
                                { id: 'normal', label: 'Обычный' },
                                { id: 'dark', label: 'Мрачный' },
                                { id: 'cute', label: 'Милый' },
                                { id: 'marine', label: 'Морской' },
                              ].map((style) => (
                                <div key={style.id} className="flex items-center space-x-2">
                                  <RadioGroupItem value={style.id} id={`style-${style.id}`} />
                                  <Label htmlFor={`style-${style.id}`} className="cursor-pointer">
                                    {style.label}
                                  </Label>
                                </div>
                              ))}
                            </div>
                          </RadioGroup>
                        </div>

                        <div className="flex items-center space-x-2">
                          <Switch
                            id="isFeatured"
                            checked={productForm.isFeatured}
                            onCheckedChange={(checked) => setProductForm({ ...productForm, isFeatured: checked })}
                          />
                          <Label htmlFor="isFeatured">Отображать на главной</Label>
                        </div>

                        <div className="space-y-4">
                          <div className="flex items-center justify-between">
                            <h3 className="text-lg font-semibold">Варианты товара</h3>
                            <Button type="button" onClick={handleAddVariant} variant="outline" size="sm">
                              <Plus className="mr-2 h-4 w-4" />
                              Добавить вариант
                            </Button>
                          </div>
                          <div className="space-y-3">
                            {productForm.variants.map((variant, index) => (
                              <div key={index} className="flex gap-3 items-start p-4 bg-muted/30 rounded-lg">
                                <div className="flex-1 grid grid-cols-3 gap-3">
                                  <div>
                                    <Label className="text-sm">Размер</Label>
                                    <Input
                                      value={variant.size}
                                      onChange={(e) => {
                                        const newVariants = [...productForm.variants]
                                        newVariants[index].size = e.target.value
                                        setProductForm({ ...productForm, variants: newVariants })
                                      }}
                                      placeholder="S, M, L..."
                                    />
                                  </div>
                                  <div>
                                    <Label className="text-sm">Цвет</Label>
                                    <Input
                                      value={variant.color}
                                      onChange={(e) => {
                                        const newVariants = [...productForm.variants]
                                        newVariants[index].color = e.target.value
                                        setProductForm({ ...productForm, variants: newVariants })
                                      }}
                                      placeholder="Чёрный, белый..."
                                    />
                                  </div>
                                  <div>
                                    <Label className="text-sm">Количество</Label>
                                    <Input
                                      type="number"
                                      value={variant.stock}
                                      onChange={(e) => {
                                        const newVariants = [...productForm.variants]
                                        newVariants[index].stock = e.target.value
                                        setProductForm({ ...productForm, variants: newVariants })
                                      }}
                                      placeholder="10"
                                      required
                                    />
                                  </div>
                                </div>
                                {productForm.variants.length > 1 && (
                                  <Button
                                    type="button"
                                    variant="ghost"
                                    size="icon"
                                    onClick={() => handleRemoveVariant(index)}
                                  >
                                    <Trash2 className="h-4 w-4" />
                                  </Button>
                                )}
                              </div>
                            ))}
                          </div>
                        </div>

                        <div className="space-y-4">
                          <div className="flex items-center justify-between">
                            <h3 className="text-lg font-semibold">Фотографии</h3>
                            <Button type="button" onClick={handleAddImage} variant="outline" size="sm">
                              <Upload className="mr-2 h-4 w-4" />
                              Добавить фото
                            </Button>
                          </div>
                          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                            {productForm.images.map((image, index) => (
                              <div key={index} className="space-y-2">
                                <div className="relative aspect-square bg-muted rounded-lg overflow-hidden">
                                  {image.url ? (
                                    <img src={image.url} alt={image.alt} className="w-full h-full object-cover" />
                                  ) : (
                                    <div className="w-full h-full flex items-center justify-center text-muted-foreground text-sm">
                                      Фото {index + 1}
                                    </div>
                                  )}
                                </div>
                                <div className="flex gap-2">
                                  <Label htmlFor={`image-upload-${index}`} className="sr-only">
                                    Загрузить фото
                                  </Label>
                                  <Input
                                    id={`image-upload-${index}`}
                                    type="file"
                                    accept="image/*"
                                    onChange={(e) => handleImageUpload(e, index)}
                                    className="text-sm"
                                  />
                                  {productForm.images.length > 1 && (
                                    <Button
                                      type="button"
                                      variant="ghost"
                                      size="icon"
                                      onClick={() => handleRemoveImage(index)}
                                    >
                                      <X className="h-4 w-4" />
                                    </Button>
                                  )}
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>

                        <div className="flex justify-end gap-3">
                          <Button type="button" variant="outline" onClick={() => setShowProductForm(false)}>
                            Отмена
                          </Button>
                          <Button type="submit" disabled={uploading}>
                            {uploading ? 'Сохранение...' : 'Сохранить товар'}
                          </Button>
                        </div>
                      </form>
                    </DialogContent>
                  </Dialog>
                </div>

                <ScrollArea className="h-[600px]">
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {products.map((product) => (
                      <Card key={product.id}>
                        <CardHeader className="pb-4">
                          <div className="flex justify-between items-start gap-2">
                            <h3 className="font-semibold text-lg">{product.name}</h3>
                            <div className="flex gap-2">
                              <Badge variant={product.isActive ? 'default' : 'secondary'}>
                                {product.isActive ? 'Активен' : 'Скрыт'}
                              </Badge>
                              {product.isFeatured && (
                                <Badge className="bg-yellow-500">
                                  Избранное
                                </Badge>
                              )}
                            </div>
                          </div>
                          <p className="text-sm text-muted-foreground">{product.category.name}</p>
                        </CardHeader>
                        <CardContent>
                          <div className="space-y-2">
                            <div className="flex items-center gap-2">
                              <span className="text-2xl font-bold">
                                {formatPrice(product.price)}
                              </span>
                              <Badge variant="outline">{product.style}</Badge>
                            </div>
                            <div className="flex gap-2 pt-4">
                              <Button variant="outline" size="sm" className="flex-1">
                                <Edit className="mr-2 h-4 w-4" />
                                Редактировать
                              </Button>
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => handleDeleteProduct(product.id)}
                              >
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </ScrollArea>
              </div>
            </TabsContent>

            {/* Promo Codes Tab */}
            <TabsContent value="promos">
              <Card>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle>Промокоды</CardTitle>
                    <Button size="sm">
                      <Plus className="mr-2 h-4 w-4" />
                      Создать промокод
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  <ScrollArea className="h-[600px]">
                    <div className="space-y-3">
                      {promoCodes.length === 0 ? (
                        <p className="text-center text-muted-foreground py-12">
                          Промокодов пока нет
                        </p>
                      ) : (
                        promoCodes.map((promo) => (
                          <div key={promo.id} className="p-4 border rounded-lg space-y-2">
                            <div className="flex items-center justify-between">
                              <div className="flex items-center gap-3">
                                <Badge className="text-lg font-bold px-3 py-1">
                                  {promo.code}
                                </Badge>
                                <Badge variant={promo.isActive ? 'default' : 'secondary'}>
                                  {promo.isActive ? 'Активен' : 'Неактивен'}
                                </Badge>
                              </div>
                              <div className="flex gap-2">
                                <Button variant="outline" size="sm">
                                  <Edit className="h-4 w-4" />
                                </Button>
                                <Button
                                  variant="outline"
                                  size="sm"
                                  onClick={() => handleDeletePromoCode(promo.id)}
                                >
                                  <Trash2 className="h-4 w-4" />
                                </Button>
                              </div>
                            </div>
                            <div className="text-sm text-muted-foreground space-y-1">
                              <div className="flex gap-4">
                                <span>Скидка: {promo.discount}{promo.type === 'percentage' ? '%' : ' ₽'}</span>
                                <span>Использовано: {promo.usedCount}/{promo.maxUses || '∞'}</span>
                              </div>
                              {promo.minAmount && <span>Мин. сумма: {promo.minAmount} ₽</span>}
                              {promo.validUntil && (
                                <span>До: {new Date(promo.validUntil).toLocaleDateString('ru-RU')}</span>
                              )}
                            </div>
                          </div>
                        ))
                      )}
                    </div>
                  </ScrollArea>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Blog Tab */}
            <TabsContent value="blog">
              <Card>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle>Блог</CardTitle>
                    <Button size="sm">
                      <Plus className="mr-2 h-4 w-4" />
                      Создать пост
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  <ScrollArea className="h-[600px]">
                    <div className="space-y-3">
                      {blogPosts.length === 0 ? (
                        <p className="text-center text-muted-foreground py-12">
                          Постов пока нет
                        </p>
                      ) : (
                        blogPosts.map((post) => (
                          <div key={post.id} className="p-4 border rounded-lg space-y-2">
                            <div className="flex items-center justify-between">
                              <h3 className="font-semibold text-lg">{post.title}</h3>
                              <div className="flex gap-2">
                                <Badge variant={post.isPublished ? 'default' : 'secondary'}>
                                  {post.isPublished ? 'Опубликован' : 'Черновик'}
                                </Badge>
                                <Button variant="outline" size="sm">
                                  <Edit className="h-4 w-4" />
                                </Button>
                                <Button
                                  variant="outline"
                                  size="sm"
                                  onClick={() => handleDeleteBlogPost(post.slug)}
                                >
                                  <Trash2 className="h-4 w-4" />
                                </Button>
                              </div>
                            </div>
                            <div className="text-sm text-muted-foreground">
                              <div className="flex gap-4">
                                <span className="flex items-center gap-1">
                                  <FileText className="h-4 w-4" />
                                  {post.slug}
                                </span>
                                <span className="flex items-center gap-1">
                                  <Tag className="h-4 w-4" />
                                  {new Date(post.createdAt).toLocaleDateString('ru-RU')}
                                </span>
                              </div>
                            </div>
                          </div>
                        ))
                      )}
                    </div>
                  </ScrollArea>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Orders Tab */}
            <TabsContent value="orders">
              <Card>
                <CardHeader>
                  <CardTitle>Все заказы</CardTitle>
                </CardHeader>
                <CardContent>
                  <ScrollArea className="h-[600px]">
                    <div className="space-y-4">
                      {stats?.recentOrders?.length === 0 ? (
                        <p className="text-center text-muted-foreground py-8">
                          Заказов пока нет
                        </p>
                      ) : (
                        stats?.recentOrders?.map((order: any) => (
                          <div
                            key={order.id}
                            className="border rounded-lg p-4 space-y-3"
                          >
                            <div className="flex justify-between items-start gap-4">
                              <div>
                                <div className="font-semibold">
                                  {order.orderNumber}
                                </div>
                                <div className="text-sm text-muted-foreground">
                                  {new Date(order.createdAt).toLocaleDateString('ru-RU', {
                                    day: 'numeric',
                                    month: 'long',
                                    year: 'numeric',
                                  })}
                                </div>
                              </div>
                              <Badge className={getStatusColor(order.status)}>
                                {getStatusLabel(order.status)}
                              </Badge>
                            </div>

                            <div className="grid grid-cols-2 gap-4 text-sm">
                              <div>
                                <div className="text-muted-foreground">Клиент</div>
                                <div className="font-medium">{order.customerName}</div>
                                <div className="text-muted-foreground">
                                  {order.customerPhone}
                                </div>
                                <div>{order.customerEmail}</div>
                              </div>
                              <div>
                                <div className="text-muted-foreground">Доставка</div>
                                <div>
                                  {order.deliveryMethod === 'cdek' ? 'СДЭК' : 'Курьер'}
                                </div>
                                <div>
                                  {order.city}
                                  {order.address && `, ${order.address}`}
                                </div>
                              </div>
                            </div>

                            <div>
                              <div className="text-muted-foreground text-sm mb-2">
                                Товары
                              </div>
                              <div className="space-y-1">
                                {order.items?.map((item: any) => (
                                  <div
                                    key={item.id}
                                    className="flex justify-between text-sm"
                                  >
                                    <span>
                                      {item.productName} x {item.quantity}
                                    </span>
                                    <span>{formatPrice(item.price * item.quantity)}</span>
                                  </div>
                                ))}
                              </div>
                            </div>

                            <div className="flex justify-between items-center pt-3 border-t">
                              <span className="font-semibold">Итого:</span>
                              <span className="text-2xl font-bold">
                                {formatPrice(order.totalAmount)}
                              </span>
                            </div>
                          </div>
                        ))
                      )}
                    </div>
                  </ScrollArea>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </main>
    </div>
  )
}
