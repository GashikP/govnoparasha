'use client'

import { useEffect, useState } from 'react'
import { Header } from '@/components/header'
import { ProductReviews } from '@/components/product-reviews'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Card, CardContent } from '@/components/ui/card'
import { Separator } from '@/components/ui/separator'
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group'
import { Label } from '@/components/ui/label'
import { ShoppingCart, ArrowLeft, Minus, Plus } from 'lucide-react'
import { useCartStore } from '@/store/cart'
import { useParams, useRouter } from 'next/navigation'
import { toast } from 'sonner'
import Image from 'next/image'

interface Product {
  id: string
  name: string
  slug: string
  description?: string
  price: number
  oldPrice?: number
  style: 'dark' | 'cute' | 'marine' | 'normal'
  category: {
    id: string
    name: string
    slug: string
  }
  variants: {
    id: string
    size?: string
    color?: string
    stock: number
  }[]
  images: {
    id: string
    url: string
    alt?: string
    order: number
  }[]
  reviews: {
    id: string
    author: string
    rating: number
    text?: string
    createdAt: string
  }[]
  averageRating?: number | null
}

export default function ProductPage() {
  const params = useParams()
  const router = useRouter()
  const { addItem } = useCartStore()
  const [product, setProduct] = useState<Product | null>(null)
  const [loading, setLoading] = useState(true)
  const [selectedVariant, setSelectedVariant] = useState<string>('')
  const [quantity, setQuantity] = useState(1)
  const [mainImage, setMainImage] = useState(0)

  useEffect(() => {
    if (params.id) {
      fetchProduct(params.id as string)
    }
  }, [params.id])

  const fetchProduct = async (id: string) => {
    try {
      const response = await fetch(`/api/products/${id}`)
      if (!response.ok) {
        router.push('/')
        return
      }
      const data = await response.json()
      setProduct(data)
      if (data.variants.length > 0) {
        setSelectedVariant(data.variants[0].id)
      }
    } catch (error) {
      console.error('Error fetching product:', error)
    } finally {
      setLoading(false)
    }
  }

  const variant = product?.variants.find((v) => v.id === selectedVariant)
  const sizes = [...new Set(product?.variants.map((v) => v.size).filter(Boolean))]
  const colors = [...new Set(product?.variants.map((v) => v.color).filter(Boolean))]

  const handleAddToCart = () => {
    if (!product || !variant) return

    addItem({
      productId: product.id,
      productName: product.name,
      productImage: product.images[0]?.url || '',
      productPrice: product.price,
      variantId: variant.id,
      variantSize: variant.size,
      variantColor: variant.color,
      quantity,
    })

    toast.success('Товар добавлен в корзину!')
  }

  const styleLabels = {
    dark: 'Мрачный',
    cute: 'Милый',
    marine: 'Морской',
    normal: 'Обычный',
  }

  const styleColors = {
    dark: 'bg-slate-700 text-slate-100',
    cute: 'bg-pink-100 text-pink-700',
    marine: 'bg-cyan-100 text-cyan-700',
    normal: 'bg-stone-100 text-stone-700',
  }

  const formatPrice = (price: number) => {
    return price.toLocaleString('ru-RU', {
      style: 'currency',
      currency: 'RUB',
    })
  }

  if (loading) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        <main className="flex-1 flex items-center justify-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
        </main>
      </div>
    )
  }

  if (!product) {
    return null
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Header />

      <main className="flex-1 py-8 px-4 md:px-8">
        <div className="container mx-auto max-w-6xl">
          <Button variant="ghost" onClick={() => router.back()} className="mb-6">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Назад
          </Button>

          {/* Product Info */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
            {/* Images */}
            <div className="space-y-4">
              <div className="relative aspect-square overflow-hidden rounded-lg border">
                <Image
                  src={product.images[mainImage]?.url || ''}
                  alt={product.name}
                  fill
                  className="object-cover"
                />
              </div>
              {product.images.length > 1 && (
                <div className="grid grid-cols-4 gap-2">
                  {product.images.map((image, index) => (
                    <button
                      key={image.id}
                      onClick={() => setMainImage(index)}
                      className={`relative aspect-square overflow-hidden rounded border-2 transition-colors ${
                        mainImage === index
                          ? 'border-primary'
                          : 'border-transparent hover:border-primary/50'
                      }`}
                    >
                      <Image
                        src={image.url}
                        alt={image.alt || product.name}
                        fill
                        className="object-cover"
                      />
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Details */}
            <div className="space-y-6">
              <div>
                <Badge className={`mb-3 ${styleColors[product.style]}`}>
                  {styleLabels[product.style]}
                </Badge>
                <h1 className="text-3xl font-bold mb-2">
                  {product.name}
                </h1>
                <p className="text-muted-foreground">
                  {product.category.name}
                </p>
              </div>

              {product.description && (
                <p className="text-muted-foreground leading-relaxed">
                  {product.description}
                </p>
              )}

              {/* Variants */}
              {sizes.length > 0 && (
                <div className="space-y-3">
                  <Label className="text-base font-medium">Размер:</Label>
                  <RadioGroup
                    value={variant?.size || ''}
                    onValueChange={(value) => {
                      const newVariant = product.variants.find(
                        (v) => v.size === value && v.color === variant?.color
                      )
                      if (newVariant) setSelectedVariant(newVariant.id)
                    }}
                  >
                    <div className="flex flex-wrap gap-2">
                      {sizes.map((size) => (
                        <div key={size} className="flex items-center space-x-2">
                          <RadioGroupItem value={size!} id={`size-${size}`} />
                          <Label htmlFor={`size-${size}`} className="cursor-pointer">
                            {size}
                          </Label>
                        </div>
                      ))}
                    </div>
                  </RadioGroup>
                </div>
              )}

              {colors.length > 0 && (
                <div className="space-y-3">
                  <Label className="text-base font-medium">Цвет:</Label>
                  <RadioGroup
                    value={variant?.color || ''}
                    onValueChange={(value) => {
                      const newVariant = product.variants.find(
                        (v) => v.color === value && v.size === variant?.size
                      )
                      if (newVariant) setSelectedVariant(newVariant.id)
                    }}
                  >
                    <div className="flex flex-wrap gap-2">
                      {colors.map((color) => (
                        <div key={color} className="flex items-center space-x-2">
                          <RadioGroupItem value={color!} id={`color-${color}`} />
                          <Label htmlFor={`color-${color}`} className="cursor-pointer">
                            {color}
                          </Label>
                        </div>
                      ))}
                    </div>
                  </RadioGroup>
                </div>
              )}

              {/* Price & Stock */}
              <div className="space-y-3">
                <div className="flex items-center gap-3">
                  <span className="text-3xl font-bold">
                    {formatPrice(product.price)}
                  </span>
                  {product.oldPrice && (
                    <span className="text-xl text-muted-foreground line-through">
                      {formatPrice(product.oldPrice)}
                    </span>
                  )}
                  {product.oldPrice && (
                    <Badge variant="destructive">
                      -
                      {Math.round(
                        ((product.oldPrice - product.price) / product.oldPrice) * 100
                      )}
                      %
                    </Badge>
                  )}
                </div>

                {variant && (
                  <p className="text-sm text-muted-foreground">
                    {variant.stock > 0
                      ? `В наличии: ${variant.stock} шт.`
                      : 'Нет в наличии'}
                  </p>
                )}

                {product.averageRating && (
                  <div className="flex items-center gap-2 text-sm">
                    <span className="font-semibold">
                      {product.averageRating.toFixed(1)}
                    </span>
                    <span className="text-muted-foreground">
                      ({product.reviews.length} отзывов)
                    </span>
                  </div>
                )}
              </div>

              {/* Quantity & Add to Cart */}
              <div className="space-y-4">
                <div className="flex items-center gap-3">
                  <Label>Количество:</Label>
                  <div className="flex items-center gap-2">
                    <Button
                      variant="outline"
                      size="icon"
                      onClick={() => setQuantity(Math.max(1, quantity - 1))}
                    >
                      <Minus className="h-4 w-4" />
                    </Button>
                    <span className="w-12 text-center text-lg font-semibold">
                      {quantity}
                    </span>
                    <Button
                      variant="outline"
                      size="icon"
                      onClick={() =>
                        setQuantity(
                          variant ? Math.min(variant.stock, quantity + 1) : quantity + 1
                        )
                      }
                    >
                      <Plus className="h-4 w-4" />
                    </Button>
                  </div>
                </div>

                <Button
                  size="lg"
                  className="w-full"
                  onClick={handleAddToCart}
                  disabled={!variant || variant.stock === 0}
                >
                  <ShoppingCart className="mr-2 h-5 w-5" />
                  {variant && variant.stock > 0
                    ? 'Добавить в корзину'
                    : 'Нет в наличии'}
                </Button>
              </div>
            </div>
          </div>

          <Separator className="my-8" />

          {/* Reviews */}
          <ProductReviews productId={product.id} reviews={product.reviews} />
        </div>
      </main>
    </div>
  )
}
