'use client'

import { useState } from 'react'
import { Header } from '@/components/header'
import { ProductCard, Product } from '@/components/product-card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Search, SlidersHorizontal } from 'lucide-react'
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from '@/components/ui/sheet'
import { Checkbox } from '@/components/ui/checkbox'
import { Label } from '@/components/ui/label'
import { Slider } from '@/components/ui/slider'

// Тестовые данные (позже заменим на реальные из API)
const mockProducts: Product[] = [
  {
    id: '1',
    name: 'Футболка "Мрачный лес"',
    slug: 'tshirt-dark-forest',
    description: 'Удобная футболка с уникальным принтом в мрачном стиле',
    price: 1500,
    oldPrice: 2000,
    style: 'dark',
    imageUrl: 'https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=500&h=500&fit=crop',
    category: 'Футболки',
    variants: [
      { id: '1-1', size: 'S', color: 'Чёрный', stock: 10 },
      { id: '1-2', size: 'M', color: 'Чёрный', stock: 5 },
      { id: '1-3', size: 'L', color: 'Чёрный', stock: 8 },
    ],
  },
  {
    id: '2',
    name: 'Футболка "Милый котик"',
    slug: 'tshirt-cute-cat',
    description: 'Милая футболка с принтом котика для радостных дней',
    price: 1500,
    style: 'cute',
    imageUrl: 'https://images.unsplash.com/photo-1576566588028-4147f3842f27?w=500&h=500&fit=crop',
    category: 'Футболки',
    variants: [
      { id: '2-1', size: 'S', color: 'Белый', stock: 15 },
      { id: '2-2', size: 'M', color: 'Белый', stock: 12 },
      { id: '2-3', size: 'L', color: 'Белый', stock: 10 },
    ],
  },
  {
    id: '3',
    name: 'Толстовка "Морские волны"',
    slug: 'hoodie-waves',
    description: 'Уютная толстовка с морским принтом',
    price: 3000,
    oldPrice: 3500,
    style: 'marine',
    imageUrl: 'https://images.unsplash.com/photo-1556821840-3a63f95609a7?w=500&h=500&fit=crop',
    category: 'Толстовки',
    variants: [
      { id: '3-1', size: 'S', color: 'Синий', stock: 7 },
      { id: '3-2', size: 'M', color: 'Синий', stock: 5 },
      { id: '3-3', size: 'L', color: 'Синий', stock: 3 },
    ],
  },
  {
    id: '4',
    name: 'Джинсовка "Классика"',
    slug: 'jacket-classic',
    description: 'Стильная джинсовая куртка в обычном стиле',
    price: 4500,
    style: 'normal',
    imageUrl: 'https://images.unsplash.com/photo-1576995853123-5a10305d93c0?w=500&h=500&fit=crop',
    category: 'Джинсовки',
    variants: [
      { id: '4-1', size: 'S', color: 'Синий', stock: 5 },
      { id: '4-2', size: 'M', color: 'Синий', stock: 4 },
      { id: '4-3', size: 'L', color: 'Синий', stock: 6 },
    ],
  },
  {
    id: '5',
    name: 'Вязаный мишка',
    slug: 'teddy-bear',
    description: 'Ручная работа. Уютный вязаный медвежонок',
    price: 2000,
    style: 'cute',
    imageUrl: 'https://images.unsplash.com/photo-1558584673-c834fb1cc3ca?w=500&h=500&fit=crop',
    category: 'Вязаные игрушки',
    variants: [
      { id: '5-1', color: 'Коричневый', stock: 3 },
    ],
  },
  {
    id: '6',
    name: 'Футболка "Тёмный замок"',
    slug: 'tshirt-dark-castle',
    description: 'Футболка с мрачным замком для любителей готики',
    price: 1800,
    style: 'dark',
    imageUrl: 'https://images.unsplash.com/photo-1583743814966-8936f5b7be1a?w=500&h=500&fit=crop',
    category: 'Футболки',
    variants: [
      { id: '6-1', size: 'S', color: 'Тёмно-серый', stock: 8 },
      { id: '6-2', size: 'M', color: 'Тёмно-серый', stock: 10 },
      { id: '6-3', size: 'L', color: 'Тёмно-серый', stock: 6 },
    ],
  },
  {
    id: '7',
    name: 'Лёгкая куртка "Морской бриз"',
    slug: 'light-jacket-breeze',
    description: 'Лёгкая ветровка для прохладной погоды',
    price: 3500,
    style: 'marine',
    imageUrl: 'https://images.unsplash.com/photo-1591047139829-d91aecb6caea?w=500&h=500&fit=crop',
    category: 'Куртки',
    variants: [
      { id: '7-1', size: 'S', color: 'Бирюзовый', stock: 4 },
      { id: '7-2', size: 'M', color: 'Бирюзовый', stock: 6 },
      { id: '7-3', size: 'L', color: 'Бирюзовый', stock: 5 },
    ],
  },
  {
    id: '8',
    name: 'Сшитый зайчик',
    slug: 'sewn-bunny',
    description: 'Сшитый вручную зайчик из мягкой ткани',
    price: 1800,
    style: 'cute',
    imageUrl: 'https://images.unsplash.com/photo-1606902965551-dce0618f7da1?w=500&h=500&fit=crop',
    category: 'Сшитые игрушки',
    variants: [
      { id: '8-1', color: 'Розовый', stock: 5 },
    ],
  },
]

const categories = [
  'Все',
  'Футболки',
  'Толстовки',
  'Куртки',
  'Джинсовки',
  'Вязаные игрушки',
  'Сшитые игрушки',
]

const styles = [
  { id: 'dark', label: 'Мрачный' },
  { id: 'cute', label: 'Милый' },
  { id: 'marine', label: 'Морской' },
  { id: 'normal', label: 'Обычный' },
]

export default function Home() {
  const [search, setSearch] = useState('')
  const [selectedCategory, setSelectedCategory] = useState('Все')
  const [selectedStyles, setSelectedStyles] = useState<string[]>([])
  const [priceRange, setPriceRange] = useState<[number, number]>([0, 10000])

  const filteredProducts = mockProducts.filter((product) => {
    const matchesSearch = product.name
      .toLowerCase()
      .includes(search.toLowerCase())
    const matchesCategory =
      selectedCategory === 'Все' || product.category === selectedCategory
    const matchesStyle =
      selectedStyles.length === 0 || selectedStyles.includes(product.style)
    const matchesPrice =
      product.price >= priceRange[0] && product.price <= priceRange[1]

    return matchesSearch && matchesCategory && matchesStyle && matchesPrice
  })

  return (
    <div className="min-h-screen flex flex-col">
      <Header />

      <main className="flex-1">
        {/* Hero Section */}
        <section className="relative bg-gradient-to-b from-pink-50 via-purple-50 to-teal-50 dark:from-pink-950/30 dark:via-purple-950/30 dark:to-teal-950/30 py-20 px-4 md:px-8">
          <div className="container mx-auto text-center">
            <h1 className="text-4xl md:text-6xl font-bold mb-6 bg-gradient-to-r from-pink-500 via-purple-500 to-teal-500 bg-clip-text text-transparent dark:from-pink-400 dark:via-purple-400 dark:to-teal-400">
              Pshish
            </h1>
            <p className="text-xl md:text-2xl mb-8 max-w-2xl mx-auto">
              Уникальный мерч ручной работы. Футболки, игрушки и аксессуары в разных стилях
            </p>
            <div className="flex flex-wrap gap-4 justify-center">
              <Button size="lg" asChild>
                <a href="#catalog">Перейти к каталогу</a>
              </Button>
              <Button size="lg" variant="outline" asChild>
                <a href="#about">Узнать больше</a>
              </Button>
            </div>
          </div>
        </section>

        {/* Catalog Section */}
        <section id="catalog" className="py-12 px-4 md:px-8">
          <div className="container mx-auto">
            <h2 className="text-3xl font-bold mb-8 text-center">Каталог</h2>

            {/* Search and Filters */}
            <div className="mb-8 space-y-4">
              <div className="flex gap-4">
                <div className="relative flex-1">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                  <Input
                    placeholder="Поиск товаров..."
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                    className="pl-10"
                  />
                </div>

                {/* Mobile Filters */}
                <Sheet>
                  <SheetTrigger asChild>
                    <Button variant="outline" className="md:hidden">
                      <SlidersHorizontal className="mr-2 h-4 w-4" />
                      Фильтры
                    </Button>
                  </SheetTrigger>
                  <SheetContent>
                    <SheetHeader>
                      <SheetTitle>Фильтры</SheetTitle>
                    </SheetHeader>
                    <FiltersContent
                      selectedStyles={selectedStyles}
                      setSelectedStyles={setSelectedStyles}
                      priceRange={priceRange}
                      setPriceRange={setPriceRange}
                      isMobile
                    />
                  </SheetContent>
                </Sheet>
              </div>

              {/* Desktop Filters */}
              <div className="hidden md:flex gap-6 items-start">
                <div className="space-y-3">
                  <h3 className="font-semibold">Категория</h3>
                  <div className="flex flex-wrap gap-2">
                    {categories.map((category) => (
                      <Button
                        key={category}
                        variant={selectedCategory === category ? 'default' : 'outline'}
                        size="sm"
                        onClick={() => setSelectedCategory(category)}
                      >
                        {category}
                      </Button>
                    ))}
                  </div>
                </div>

                <div className="space-y-3 flex-1">
                  <h3 className="font-semibold">Стиль</h3>
                  <div className="flex flex-wrap gap-2">
                    {styles.map((style) => (
                      <Button
                        key={style.id}
                        variant={
                          selectedStyles.includes(style.id) ? 'default' : 'outline'
                        }
                        size="sm"
                        onClick={() => {
                          if (selectedStyles.includes(style.id)) {
                            setSelectedStyles(
                              selectedStyles.filter((s) => s !== style.id)
                            )
                          } else {
                            setSelectedStyles([...selectedStyles, style.id])
                          }
                        }}
                      >
                        {style.label}
                      </Button>
                    ))}
                  </div>
                </div>

                <div className="space-y-3 w-64">
                  <h3 className="font-semibold">Цена: {priceRange[0]} - {priceRange[1]} ₽</h3>
                  <Slider
                    value={priceRange}
                    onValueChange={(value) =>
                      setPriceRange([value[0], value[1]])
                    }
                    min={0}
                    max={10000}
                    step={100}
                    className="w-full"
                  />
                </div>
              </div>
            </div>

            {/* Products Grid */}
            {filteredProducts.length === 0 ? (
              <div className="text-center py-12 text-muted-foreground">
                Товары не найдены
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                {filteredProducts.map((product) => (
                  <ProductCard key={product.id} product={product} />
                ))}
              </div>
            )}
          </div>
        </section>

        {/* About Section */}
        <section id="about" className="py-12 px-4 md:px-8 bg-muted/50">
          <div className="container mx-auto max-w-4xl">
            <h2 className="text-3xl font-bold mb-6 text-center">О нас</h2>
            <div className="prose prose-lg max-w-none text-muted-foreground">
              <p className="text-center">
                Добро пожаловать в Pshish! Мы создаём уникальные товары ручной работы,
                которые приносят радость и выражают вашу индивидуальность. Каждый товар
                создан с любовью и вниманием к деталям.
              </p>
              <p className="text-center mt-4">
                Наши работы охватывают разные стили — от мрачного до милого,
                от морского до классического, чтобы каждый мог найти что-то по душе.
              </p>
            </div>
          </div>
        </section>

        {/* Blog Section */}
        <section id="blog" className="py-12 px-4 md:px-8">
          <div className="container mx-auto">
            <h2 className="text-3xl font-bold mb-8 text-center">Блог</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {[1, 2, 3].map((i) => (
                <div key={i} className="border rounded-lg p-6 space-y-3">
                  <div className="h-40 bg-muted rounded-lg"></div>
                  <h3 className="font-semibold">Процесс создания #{i}</h3>
                  <p className="text-sm text-muted-foreground">
                    История о том, как мы создавали этот уникальный товар...
                  </p>
                  <Button variant="link" className="p-0">
                    Читать далее →
                  </Button>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Contacts Section */}
        <section id="contacts" className="py-12 px-4 md:px-8 bg-muted/50">
          <div className="container mx-auto max-w-4xl text-center">
            <h2 className="text-3xl font-bold mb-6">Контакты</h2>
            <div className="space-y-4">
              <p className="text-xl">📞 8 (950) 828-02-13</p>
              <p className="text-xl">📱 @loomanager</p>
              <p className="text-muted-foreground">
                Чат в Telegram: нажми на кнопку ниже
              </p>
              <Button size="lg" asChild>
                <a
                  href="https://t.me/loomanager"
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  Написать в Telegram
                </a>
              </Button>
            </div>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="border-t bg-muted/30 mt-auto">
        <div className="container mx-auto py-8 px-4 md:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div>
              <h3 className="font-bold text-lg mb-4">Pshish</h3>
              <p className="text-sm text-muted-foreground">
                Уникальный мерч ручной работы
              </p>
            </div>
            <div>
              <h3 className="font-bold text-lg mb-4">Информация</h3>
              <ul className="space-y-2 text-sm">
                <li>
                  <a href="#about" className="text-muted-foreground hover:text-primary">
                    О нас
                  </a>
                </li>
                <li>
                  <a href="#contacts" className="text-muted-foreground hover:text-primary">
                    Контакты
                  </a>
                </li>
                <li>
                  <a href="#blog" className="text-muted-foreground hover:text-primary">
                    Блог
                  </a>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="font-bold text-lg mb-4">Подписка</h3>
              <p className="text-sm text-muted-foreground mb-4">
                Подпишись на рассылку, чтобы не пропустить новинки и акции
              </p>
              <div className="flex gap-2">
                <Input placeholder="Ваш email" className="flex-1" />
                <Button>Подписаться</Button>
              </div>
            </div>
          </div>
          <div className="mt-8 pt-8 border-t text-center text-sm text-muted-foreground">
            © {new Date().getFullYear()} Pshish. Все права защищены.
          </div>
        </div>
      </footer>
    </div>
  )
}

function FiltersContent({
  selectedStyles,
  setSelectedStyles,
  priceRange,
  setPriceRange,
  isMobile,
}: {
  selectedStyles: string[]
  setSelectedStyles: (styles: string[]) => void
  priceRange: [number, number]
  setPriceRange: (range: [number, number]) => void
  isMobile: boolean
}) {
  return (
    <div className="space-y-6 py-4">
      <div className="space-y-3">
        <h3 className="font-semibold">Стиль</h3>
        {styles.map((style) => (
          <div key={style.id} className="flex items-center space-x-2">
            <Checkbox
              id={`mobile-style-${style.id}`}
              checked={selectedStyles.includes(style.id)}
              onCheckedChange={(checked) => {
                if (checked) {
                  setSelectedStyles([...selectedStyles, style.id])
                } else {
                  setSelectedStyles(selectedStyles.filter((s) => s !== style.id))
                }
              }}
            />
            <Label htmlFor={`mobile-style-${style.id}`}>{style.label}</Label>
          </div>
        ))}
      </div>

      <div className="space-y-3">
        <h3 className="font-semibold">Цена: {priceRange[0]} - {priceRange[1]} ₽</h3>
        <Slider
          value={priceRange}
          onValueChange={(value) => setPriceRange([value[0], value[1]])}
          min={0}
          max={10000}
          step={100}
          className="w-full"
        />
      </div>
    </div>
  )
}
