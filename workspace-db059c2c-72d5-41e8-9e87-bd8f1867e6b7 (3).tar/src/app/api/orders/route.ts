import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

interface OrderItem {
  productId: string
  variantId: string
  quantity: number
}

interface CreateOrderData {
  customerName: string
  customerEmail: string
  customerPhone: string
  deliveryMethod: 'cdek' | 'courier'
  deliveryCost: number
  address?: string
  city?: string
  promoCode?: string
  notes?: string
  items: OrderItem[]
}

export async function POST(request: NextRequest) {
  try {
    const data: CreateOrderData = await request.json()

    // Validate required fields
    if (
      !data.customerName ||
      !data.customerEmail ||
      !data.customerPhone ||
      !data.deliveryMethod ||
      !data.items ||
      data.items.length === 0
    ) {
      return NextResponse.json(
        { error: 'Missing required fields' },
        { status: 400 }
      )
    }

    // Check promo code if provided
    let discountAmount = 0
    if (data.promoCode) {
      const promoCode = await db.promoCode.findUnique({
        where: { code: data.promoCode.toUpperCase() },
      })

      if (!promoCode || !promoCode.isActive) {
        return NextResponse.json(
          { error: 'Invalid promo code' },
          { status: 400 }
        )
      }

      const now = new Date()
      if (
        promoCode.validUntil &&
        new Date(promoCode.validUntil) < now
      ) {
        return NextResponse.json(
          { error: 'Promo code has expired' },
          { status: 400 }
        )
      }

      if (
        promoCode.maxUses &&
        promoCode.usedCount >= promoCode.maxUses
      ) {
        return NextResponse.json(
          { error: 'Promo code has reached maximum uses' },
          { status: 400 }
        )
      }

      // Calculate discount (will be applied later based on total)
    }

    // Fetch products and calculate total
    let totalAmount = 0
    const orderItems = []

    for (const item of data.items) {
      const product = await db.product.findUnique({
        where: { id: item.productId },
        include: { variants: true },
      })

      if (!product) {
        return NextResponse.json(
          { error: `Product ${item.productId} not found` },
          { status: 404 }
        )
      }

      const variant = product.variants.find((v) => v.id === item.variantId)
      if (!variant) {
        return NextResponse.json(
          { error: `Variant ${item.variantId} not found` },
          { status: 404 }
        )
      }

      if (variant.stock < item.quantity) {
        return NextResponse.json(
          { error: `Not enough stock for ${product.name}` },
          { status: 400 }
        )
      }

      totalAmount += product.price * item.quantity

      orderItems.push({
        productId: item.productId,
        variantId: item.variantId,
        productName: product.name,
        variantSize: variant.size,
        variantColor: variant.color,
        price: product.price,
        quantity: item.quantity,
      })
    }

    // Apply promo code discount
    if (data.promoCode && discountAmount === 0) {
      const promoCode = await db.promoCode.findUnique({
        where: { code: data.promoCode.toUpperCase() },
      })

      if (promoCode) {
        if (promoCode.type === 'percentage') {
          discountAmount = (totalAmount * promoCode.discount) / 100
        } else {
          discountAmount = promoCode.discount
        }

        // Update promo code usage count
        await db.promoCode.update({
          where: { id: promoCode.id },
          data: { usedCount: { increment: 1 } },
        })
      }
    }

    // Add delivery cost
    totalAmount += data.deliveryCost - discountAmount

    // Generate order number
    const orderNumber = `ORD-${Date.now().toString().slice(-8)}`

    // Create order
    const order = await db.order.create({
      data: {
        orderNumber,
        customerName: data.customerName,
        customerEmail: data.customerEmail,
        customerPhone: data.customerPhone,
        deliveryMethod: data.deliveryMethod,
        deliveryCost: data.deliveryCost,
        address: data.address,
        city: data.city,
        promoCode: data.promoCode,
        discountAmount,
        totalAmount,
        notes: data.notes,
        paymentMethod: 't_bank',
        status: 'pending',
        items: {
          create: orderItems,
        },
      },
      include: {
        items: true,
      },
    })

    // Update stock
    for (const item of data.items) {
      await db.productVariant.update({
        where: { id: item.variantId },
        data: {
          stock: {
            decrement: item.quantity,
          },
        },
      })
    }

    return NextResponse.json(order)
  } catch (error) {
    console.error('Error creating order:', error)
    return NextResponse.json(
      { error: 'Failed to create order' },
      { status: 500 }
    )
  }
}

export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams
    const status = searchParams.get('status')

    const where: any = {}
    if (status) {
      where.status = status
    }

    const orders = await db.order.findMany({
      where,
      include: {
        items: true,
        user: {
          select: {
            id: true,
            name: true,
            email: true,
          },
        },
      },
      orderBy: {
        createdAt: 'desc',
      },
    })

    return NextResponse.json(orders)
  } catch (error) {
    console.error('Error fetching orders:', error)
    return NextResponse.json(
      { error: 'Failed to fetch orders' },
      { status: 500 }
    )
  }
}
