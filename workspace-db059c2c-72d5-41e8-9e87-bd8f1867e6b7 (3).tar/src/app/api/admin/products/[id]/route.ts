import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// Update product
export async function PATCH(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const body = await request.json()

    const {
      name,
      slug,
      description,
      price,
      oldPrice,
      categoryId,
      style,
      isActive,
      isFeatured,
    } = body

    // Check if slug is unique (excluding current product)
    if (slug) {
      const existingProduct = await db.product.findFirst({
        where: {
          slug,
          NOT: {
            id: params.id,
          },
        },
      })

      if (existingProduct) {
        return NextResponse.json(
          { error: 'Slug already exists' },
          { status: 400 }
        )
      }
    }

    const product = await db.product.update({
      where: {
        id: params.id,
      },
      data: {
        ...(name && { name }),
        ...(slug && { slug }),
        ...(description !== undefined && { description }),
        ...(price && { price }),
        ...(oldPrice !== undefined && { oldPrice }),
        ...(categoryId && { categoryId }),
        ...(style && { style }),
        ...(isActive !== undefined && { isActive }),
        ...(isFeatured !== undefined && { isFeatured }),
      },
      include: {
        variants: true,
        images: true,
        category: true,
      },
    })

    return NextResponse.json(product)
  } catch (error) {
    console.error('Error updating product:', error)
    return NextResponse.json(
      { error: 'Failed to update product' },
      { status: 500 }
    )
  }
}

// Delete product
export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    await db.product.delete({
      where: {
        id: params.id,
      },
    })

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error('Error deleting product:', error)
    return NextResponse.json(
      { error: 'Failed to delete product' },
      { status: 500 }
    )
  }
}
