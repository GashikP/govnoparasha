import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// Create product
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()

    const {
      name,
      slug,
      description,
      price,
      oldPrice,
      categoryId,
      style,
      variants,
      images,
      isFeatured = false,
    } = body

    // Validation
    if (!name || !slug || !price || !categoryId || !style) {
      return NextResponse.json(
        { error: 'Missing required fields' },
        { status: 400 }
      )
    }

    // Check if slug is unique
    const existingProduct = await db.product.findUnique({
      where: { slug },
    })

    if (existingProduct) {
      return NextResponse.json(
        { error: 'Slug already exists' },
        { status: 400 }
      )
    }

    // Create product
    const product = await db.product.create({
      data: {
        name,
        slug,
        description,
        price,
        oldPrice,
        categoryId,
        style,
        isFeatured,
        isActive: true,
        variants: {
          create: variants || [],
        },
        images: {
          create: images || [],
        },
      },
      include: {
        variants: true,
        images: true,
        category: true,
      },
    })

    return NextResponse.json(product)
  } catch (error) {
    console.error('Error creating product:', error)
    return NextResponse.json(
      { error: 'Failed to create product' },
      { status: 500 }
    )
  }
}

// Get all products (for admin)
export async function GET() {
  try {
    const products = await db.product.findMany({
      include: {
        category: true,
        variants: true,
        images: {
          orderBy: {
            order: 'asc',
          },
        },
        _count: {
          select: {
            orderItems: true,
          },
        },
      },
      orderBy: {
        createdAt: 'desc',
      },
    })

    return NextResponse.json(products)
  } catch (error) {
    console.error('Error fetching products:', error)
    return NextResponse.json(
      { error: 'Failed to fetch products' },
      { status: 500 }
    )
  }
}
