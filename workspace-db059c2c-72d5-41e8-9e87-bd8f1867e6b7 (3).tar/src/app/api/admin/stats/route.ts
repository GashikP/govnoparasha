import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET() {
  try {
    const totalOrders = await db.order.count()

    const totalRevenue = await db.order.aggregate({
      _sum: {
        totalAmount: true,
      },
    })

    const ordersByStatus = await db.order.groupBy({
      by: ['status'],
      _count: {
        status: true,
      },
    })

    const recentOrders = await db.order.findMany({
      take: 10,
      orderBy: {
        createdAt: 'desc',
      },
      include: {
        items: true,
      },
    })

    const totalProducts = await db.product.count({
      where: {
        isActive: true,
      },
    })

    const lowStockProducts = await db.productVariant.findMany({
      where: {
        stock: {
          lte: 5,
          gt: 0,
        },
      },
      include: {
        product: {
          select: {
            name: true,
          },
        },
      },
      take: 10,
    })

    return NextResponse.json({
      totalOrders,
      totalRevenue: totalRevenue._sum.totalAmount || 0,
      ordersByStatus,
      recentOrders,
      totalProducts,
      lowStockProducts,
    })
  } catch (error) {
    console.error('Error fetching stats:', error)
    return NextResponse.json(
      { error: 'Failed to fetch stats' },
      { status: 500 }
    )
  }
}
