import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

interface LoginData {
  email?: string
  phone?: string
  name?: string
}

export async function POST(request: NextRequest) {
  try {
    const body: LoginData = await request.json()

    if (!body.email && !body.phone) {
      return NextResponse.json(
        { error: 'Email или телефон обязателен' },
        { status: 400 }
      )
    }

    // Try to find existing user
    let user = await db.user.findFirst({
      where: {
        OR: [
          ...(body.email ? [{ email: body.email }] : []),
          ...(body.phone ? [{ phone: body.phone }] : []),
        ],
      },
    })

    // If user doesn't exist, create one
    if (!user) {
      if (!body.email && !body.phone) {
        return NextResponse.json(
          { error: 'Email или телефон обязателен для регистрации' },
          { status: 400 }
        )
      }

      user = await db.user.create({
        data: {
          email: body.email || `user_${Date.now()}@temp.com`,
          phone: body.phone,
          name: body.name,
          isAdmin: false,
        },
      })
    } else {
      // Update name if provided
      if (body.name) {
        user = await db.user.update({
          where: { id: user.id },
          data: { name: body.name },
        })
      }
    }

    // Return user data (in production, this should be a JWT token)
    return NextResponse.json({
      user: {
        id: user.id,
        email: user.email,
        name: user.name,
        phone: user.phone,
        isAdmin: user.isAdmin,
      },
    })
  } catch (error) {
    console.error('Error in auth:', error)
    return NextResponse.json(
      { error: 'Ошибка авторизации' },
      { status: 500 }
    )
  }
}
