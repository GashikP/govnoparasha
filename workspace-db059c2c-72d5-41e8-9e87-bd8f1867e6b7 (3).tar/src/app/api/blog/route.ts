import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// Get all blog posts (public)
export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams
    const published = searchParams.get('published')

    const where: any = {}
    if (published === 'true') {
      where.isPublished = true
    }

    const posts = await db.blogPost.findMany({
      where,
      orderBy: {
        createdAt: 'desc',
      },
    })

    return NextResponse.json(posts)
  } catch (error) {
    console.error('Error fetching blog posts:', error)
    return NextResponse.json(
      { error: 'Failed to fetch blog posts' },
      { status: 500 }
    )
  }
}

// Create blog post (admin)
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()

    const { title, slug, content, excerpt, coverImage, isPublished } = body

    // Validation
    if (!title || !slug || !content) {
      return NextResponse.json(
        { error: 'Title, slug, and content are required' },
        { status: 400 }
      )
    }

    // Check if slug is unique
    const existingPost = await db.blogPost.findUnique({
      where: { slug },
    })

    if (existingPost) {
      return NextResponse.json(
        { error: 'Slug already exists' },
        { status: 400 }
      )
    }

    const post = await db.blogPost.create({
      data: {
        title,
        slug,
        content,
        excerpt,
        coverImage,
        isPublished: isPublished || false,
      },
    })

    return NextResponse.json(post)
  } catch (error) {
    console.error('Error creating blog post:', error)
    return NextResponse.json(
      { error: 'Failed to create blog post' },
      { status: 500 }
    )
  }
}
