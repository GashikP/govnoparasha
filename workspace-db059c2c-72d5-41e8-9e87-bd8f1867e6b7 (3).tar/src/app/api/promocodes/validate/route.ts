import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams
    const code = searchParams.get('code')
    const orderAmount = searchParams.get('orderAmount')

    if (!code) {
      return NextResponse.json(
        { error: 'Promo code is required' },
        { status: 400 }
      )
    }

    const promoCode = await db.promoCode.findUnique({
      where: { code: code.toUpperCase() },
    })

    if (!promoCode) {
      return NextResponse.json(
        { error: 'Promo code not found' },
        { status: 404 }
      )
    }

    // Check if active
    if (!promoCode.isActive) {
      return NextResponse.json(
        { error: 'Promo code is not active' },
        { status: 400 }
      )
    }

    // Check if expired
    if (promoCode.validUntil && new Date(promoCode.validUntil) < new Date()) {
      return NextResponse.json(
        { error: 'Promo code has expired' },
        { status: 400 }
      )
    }

    // Check if not yet valid
    if (promoCode.validFrom && new Date(promoCode.validFrom) > new Date()) {
      return NextResponse.json(
        { error: 'Promo code is not yet valid' },
        { status: 400 }
      )
    }

    // Check max uses
    if (promoCode.maxUses && promoCode.usedCount >= promoCode.maxUses) {
      return NextResponse.json(
        { error: 'Promo code has reached maximum uses' },
        { status: 400 }
      )
    }

    // Check minimum order amount
    if (promoCode.minAmount) {
      const orderAmountNum = orderAmount ? parseFloat(orderAmount) : 0
      if (orderAmountNum < promoCode.minAmount) {
        return NextResponse.json(
          {
            error: `Minimum order amount is ${promoCode.minAmount} ₽`,
          },
          { status: 400 }
        )
      }
    }

    // Calculate discount
    let discount = 0
    const orderAmountNum = orderAmount ? parseFloat(orderAmount) : 0

    if (promoCode.type === 'percentage') {
      discount = (orderAmountNum * promoCode.discount) / 100
    } else {
      discount = promoCode.discount
    }

    return NextResponse.json({
      valid: true,
      discount,
      type: promoCode.type,
      discountValue: promoCode.discount,
    })
  } catch (error) {
    console.error('Error validating promo code:', error)
    return NextResponse.json(
      { error: 'Failed to validate promo code' },
      { status: 500 }
    )
  }
}
