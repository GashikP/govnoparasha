import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// Get all promo codes (admin)
export async function GET() {
  try {
    const promoCodes = await db.promoCode.findMany({
      orderBy: {
        createdAt: 'desc',
      },
    })

    return NextResponse.json(promoCodes)
  } catch (error) {
    console.error('Error fetching promo codes:', error)
    return NextResponse.json(
      { error: 'Failed to fetch promo codes' },
      { status: 500 }
    )
  }
}

// Create promo code
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()

    const {
      code,
      discount,
      type,
      minAmount,
      maxUses,
      validFrom,
      validUntil,
      isActive,
    } = body

    // Validation
    if (!code || !discount || !type) {
      return NextResponse.json(
        { error: 'Code, discount, and type are required' },
        { status: 400 }
      )
    }

    if (type !== 'percentage' && type !== 'fixed') {
      return NextResponse.json(
        { error: 'Type must be percentage or fixed' },
        { status: 400 }
      )
    }

    if (discount <= 0) {
      return NextResponse.json(
        { error: 'Discount must be greater than 0' },
        { status: 400 }
      )
    }

    if (type === 'percentage' && discount > 100) {
      return NextResponse.json(
        { error: 'Percentage discount cannot exceed 100%' },
        { status: 400 }
      )
    }

    // Check if code already exists
    const existingCode = await db.promoCode.findUnique({
      where: { code: code.toUpperCase() },
    })

    if (existingCode) {
      return NextResponse.json(
        { error: 'Promo code already exists' },
        { status: 400 }
      )
    }

    const promoCode = await db.promoCode.create({
      data: {
        code: code.toUpperCase(),
        discount,
        type,
        minAmount,
        maxUses,
        validFrom: validFrom ? new Date(validFrom) : undefined,
        validUntil: validUntil ? new Date(validUntil) : undefined,
        isActive: isActive !== undefined ? isActive : true,
      },
    })

    return NextResponse.json(promoCode)
  } catch (error) {
    console.error('Error creating promo code:', error)
    return NextResponse.json(
      { error: 'Failed to create promo code' },
      { status: 500 }
    )
  }
}

// Delete promo code by ID
export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    await db.promoCode.delete({
      where: { id: params.id },
    })

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error('Error deleting promo code:', error)
    return NextResponse.json(
      { error: 'Failed to delete promo code' },
      { status: 500 }
    )
  }
}
