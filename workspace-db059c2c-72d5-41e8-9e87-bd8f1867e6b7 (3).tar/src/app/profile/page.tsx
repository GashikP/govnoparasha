'use client'

import { useEffect, useState } from 'react'
import { Header } from '@/components/header'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Separator } from '@/components/ui/separator'
import {
  Package,
  Settings,
  LogOut,
  User as UserIcon,
  MapPin,
  Phone,
  Mail,
  Calendar,
  Truck,
  Check,
  Clock,
  Heart,
  ClipboardList,
} from 'lucide-react'
import { useAuthStore, User } from '@/store/auth'
import { toast } from 'sonner'
import { useRouter } from 'next/navigation'

interface Order {
  id: string
  orderNumber: string
  status: string
  totalAmount: number
  createdAt: string
  deliveryMethod: string
  city?: string
  address?: string
  items: {
    productName: string
    quantity: number
    price: number
    product: {
      images: { url: string }[]
    }
  }[]
}

export default function ProfilePage() {
  const router = useRouter()
  const { user, setUser, logout } = useAuthStore()
  const [orders, setOrders] = useState<Order[]>([])
  const [loading, setLoading] = useState(true)
  const [activeTab, setActiveTab] = useState('overview')

  // Profile settings
  const [settings, setSettings] = useState({
    name: user?.name || '',
    phone: user?.phone || '',
    email: user?.email || '',
    city: '',
    address: '',
    subscribeToNewsletter: true,
  })

  const [saving, setSaving] = useState(false)

  useEffect(() => {
    if (!user) {
      router.push('/')
      return
    }
    fetchOrders()
  }, [user, router])

  const fetchOrders = async () => {
    if (!user) return

    try {
      const response = await fetch(`/api/user/orders?userId=${user.id}`)
      const data = await response.json()
      setOrders(data)
    } catch (error) {
      console.error('Error fetching orders:', error)
      toast.error('Ошибка загрузки заказов')
    } finally {
      setLoading(false)
    }
  }

  const handleSaveSettings = async () => {
    if (!user) return

    setSaving(true)
    try {
      const response = await fetch('/api/user', {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          userId: user.id,
          name: settings.name,
          phone: settings.phone,
        }),
      })

      if (!response.ok) {
        throw new Error('Failed to update profile')
      }

      const updatedUser = await response.json()
      setUser(updatedUser)
      toast.success('Настройки сохранены')
    } catch (error) {
      console.error('Error updating profile:', error)
      toast.error('Ошибка сохранения настроек')
    } finally {
      setSaving(false)
    }
  }

  const handleLogout = () => {
    logout()
    toast.success('Вы вышли из аккаунта')
    router.push('/')
  }

  const handleAddToWishlist = (orderId: string) => {
    // TODO: Implement wishlist
    toast.info('Добавлено в избранное (скоро)')
  }

  const getStatusColor = (status: string) => {
    const colors: Record<string, string> = {
      pending: 'bg-yellow-500',
      paid: 'bg-blue-500',
      processing: 'bg-purple-500',
      shipped: 'bg-cyan-500',
      delivered: 'bg-green-500',
      cancelled: 'bg-red-500',
    }
    return colors[status] || 'bg-gray-500'
  }

  const getStatusLabel = (status: string) => {
    const labels: Record<string, string> = {
      pending: 'Ожидает оплаты',
      paid: 'Оплачен',
      processing: 'В обработке',
      shipped: 'Отправлен',
      delivered: 'Доставлен',
      cancelled: 'Отменён',
    }
    return labels[status] || status
  }

  const getStatusIcon = (status: string) => {
    const icons: Record<string, React.ReactNode> = {
      pending: <Clock className="h-4 w-4" />,
      paid: <Check className="h-4 w-4" />,
      processing: <Package className="h-4 w-4" />,
      shipped: <Truck className="h-4 w-4" />,
      delivered: <Package className="h-4 w-4" />,
      cancelled: <Clock className="h-4 w-4" />,
    }
    return icons[status] || <Clock className="h-4 w-4" />
  }

  const formatPrice = (price: number) => {
    return price.toLocaleString('ru-RU', {
      style: 'currency',
      currency: 'RUB',
    })
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('ru-RU', {
      day: 'numeric',
      month: 'long',
      year: 'numeric',
    })
  }

  if (!user) {
    return null
  }

  const orderStats = {
    total: orders.length,
    pending: orders.filter((o) => o.status === 'pending').length,
      processing: orders.filter((o) => o.status === 'processing').length,
      shipped: orders.filter((o) => o.status === 'shipped').length,
      delivered: orders.filter((o) => o.status === 'delivered').length,
      totalSpent: orders.reduce((sum, o) => sum + o.totalAmount, 0),
    }

  return (
    <div className="min-h-screen flex flex-col">
      <Header />

      <main className="flex-1 py-8 px-4 md:px-8">
        <div className="container mx-auto max-w-6xl">
          {/* Header */}
          <div className="mb-8">
            <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
              <div className="flex items-center gap-4">
                <div className="h-16 w-16 rounded-full bg-gradient-to-br from-pink-500 to-purple-500 flex items-center justify-center text-white text-2xl font-bold">
                  {user.name ? user.name.charAt(0).toUpperCase() : user.email.charAt(0).toUpperCase()}
                </div>
                <div>
                  <h1 className="text-2xl font-bold">{user.name || 'Пользователь'}</h1>
                  <p className="text-sm text-muted-foreground">{user.email}</p>
                </div>
              </div>
              <Button variant="outline" onClick={handleLogout}>
                <LogOut className="mr-2 h-4 w-4" />
                Выйти
              </Button>
            </div>
          </div>

          <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
            <TabsList className="grid w-full grid-cols-2 md:grid-cols-5">
              <TabsTrigger value="overview" className="gap-2">
                <UserIcon className="h-4 w-4" />
                Обзор
              </TabsTrigger>
              <TabsTrigger value="orders" className="gap-2">
                <Package className="h-4 w-4" />
                Заказы
              </TabsTrigger>
              <TabsTrigger value="wishlist" className="gap-2">
                <Heart className="h-4 w-4" />
                Избранное
              </TabsTrigger>
              <TabsTrigger value="settings" className="gap-2">
                <Settings className="h-4 w-4" />
                Настройки
              </TabsTrigger>
            </TabsList>

            {/* Overview Tab */}
            <TabsContent value="overview">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {/* Stats Cards */}
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between pb-2">
                    <CardTitle className="text-sm font-medium">Всего заказов</CardTitle>
                    <ClipboardList className="h-4 w-4 text-muted-foreground" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-3xl font-bold">{orderStats.total}</div>
                    <p className="text-xs text-muted-foreground mt-1">
                      {orderStats.pending} в ожидании
                    </p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="flex flex-row items-center justify-between pb-2">
                    <CardTitle className="text-sm font-medium">Доставлено</CardTitle>
                    <Check className="h-4 w-4 text-green-500" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-3xl font-bold text-green-600">
                      {orderStats.delivered}
                    </div>
                    <p className="text-xs text-muted-foreground mt-1">
                      {orderStats.shipped} в пути
                    </p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="flex flex-row items-center justify-between pb-2">
                    <CardTitle className="text-sm font-medium">Всего потрачено</CardTitle>
                    <Package className="h-4 w-4 text-muted-foreground" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-3xl font-bold">
                      {formatPrice(orderStats.totalSpent)}
                    </div>
                    <p className="text-xs text-muted-foreground mt-1">
                      За всё время
                    </p>
                  </CardContent>
                </Card>
              </div>

              {/* Order Status */}
              <Card>
                <CardHeader>
                  <CardTitle>Статус заказов</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {[
                      { label: 'Ожидает оплаты', count: orderStats.pending, color: 'yellow' },
                      { label: 'В обработке', count: orderStats.processing, color: 'purple' },
                      { label: 'Отправлено', count: orderStats.shipped, color: 'cyan' },
                      { label: 'Доставлено', count: orderStats.delivered, color: 'green' },
                    ].map((status) => (
                      <div key={status.label} className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <div className={`h-3 w-3 rounded-full bg-${status.color}-500`} />
                          <span className="text-sm">{status.label}</span>
                        </div>
                        <span className="font-semibold">{status.count}</span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Recent Orders */}
              <Card>
                <CardHeader>
                  <CardTitle>Последние заказы</CardTitle>
                </CardHeader>
                <CardContent>
                  {loading ? (
                    <div className="flex items-center justify-center py-8">
                      <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
                    </div>
                  ) : orders.length === 0 ? (
                    <div className="text-center py-8 text-muted-foreground">
                      <Package className="h-12 w-12 mx-auto mb-4 opacity-50" />
                      <p>Заказов пока нет</p>
                      <Button
                        onClick={() => router.push('/')}
                        className="mt-4"
                      >
                        Перейти в каталог
                      </Button>
                    </div>
                  ) : (
                    <ScrollArea className="max-h-[400px]">
                      <div className="space-y-3">
                        {orders.slice(0, 5).map((order) => (
                          <div
                            key={order.id}
                            className="flex items-start gap-4 p-4 border rounded-lg hover:bg-accent/50 cursor-pointer"
                            onClick={() => router.push(`/profile/orders/${order.id}`)}
                          >
                            <div className={`h-10 w-10 rounded-full flex items-center justify-center text-white ${getStatusColor(order.status)}`}>
                              {getStatusIcon(order.status)}
                            </div>
                            <div className="flex-1 min-w-0">
                              <div className="flex justify-between items-start mb-1">
                                <div>
                                  <h4 className="font-semibold">{order.orderNumber}</h4>
                                  <p className="text-xs text-muted-foreground">
                                    {formatDate(order.createdAt)}
                                  </p>
                                </div>
                                <Badge className={getStatusColor(order.status)}>
                                  {getStatusLabel(order.status)}
                                </Badge>
                              </div>
                              <p className="text-sm font-medium">
                                {formatPrice(order.totalAmount)}
                              </p>
                              <p className="text-xs text-muted-foreground">
                                {order.items.length} {order.items.length === 1 ? 'товар' : 'товаров'}
                              </p>
                            </div>
                          </div>
                        ))}
                      </div>
                    </ScrollArea>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            {/* Orders Tab */}
            <TabsContent value="orders">
              <Card>
                <CardHeader>
                  <CardTitle>История заказов</CardTitle>
                </CardHeader>
                <CardContent>
                  {loading ? (
                    <div className="flex items-center justify-center py-12">
                      <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
                    </div>
                  ) : orders.length === 0 ? (
                    <div className="text-center py-12 text-muted-foreground">
                      <Package className="h-16 w-16 mx-auto mb-4 opacity-50" />
                      <h3 className="text-lg font-semibold mb-2">
                        Заказов пока нет
                      </h3>
                      <p className="mb-4">
                        Когда вы сделаете первый заказ, он появится здесь
                      </p>
                      <Button onClick={() => router.push('/')}>
                        Перейти в каталог
                      </Button>
                    </div>
                  ) : (
                    <ScrollArea className="max-h-[600px]">
                      <div className="space-y-4">
                        {orders.map((order) => (
                          <OrderCard
                            key={order.id}
                            order={order}
                            getStatusColor={getStatusColor}
                            getStatusLabel={getStatusLabel}
                            getStatusIcon={getStatusIcon}
                            formatPrice={formatPrice}
                            formatDate={formatDate}
                          />
                        ))}
                      </div>
                    </ScrollArea>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            {/* Wishlist Tab */}
            <TabsContent value="wishlist">
              <Card>
                <CardContent className="py-12">
                  <div className="text-center">
                    <Heart className="h-16 w-16 mx-auto mb-4 opacity-50 text-muted-foreground" />
                    <h3 className="text-lg font-semibold mb-2">
                      Избранное
                    </h3>
                    <p className="text-muted-foreground mb-6 max-w-md mx-auto">
                      Функция избранного скоро будет доступна. Вы сможете сохранять любимые товары и следить за их наличием.
                    </p>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Settings Tab */}
            <TabsContent value="settings">
              <Card>
                <CardHeader>
                  <CardTitle>Настройки профиля</CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold">Личная информация</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="name">Имя</Label>
                        <Input
                          id="name"
                          value={settings.name}
                          onChange={(e) =>
                            setSettings({ ...settings, name: e.target.value })
                          }
                          placeholder="Ваше имя"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="phone">Телефон</Label>
                        <Input
                          id="phone"
                          type="tel"
                          value={settings.phone}
                          onChange={(e) =>
                            setSettings({ ...settings, phone: e.target.value })
                          }
                          placeholder="+7 (999) 999-99-99"
                        />
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="email">Email</Label>
                      <Input
                        id="email"
                        type="email"
                        value={settings.email}
                        disabled
                        className="bg-muted"
                      />
                      <p className="text-xs text-muted-foreground">
                        Email изменить нельзя, он используется для авторизации
                      </p>
                    </div>
                  </div>

                  <Separator />

                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold">Адрес доставки</h3>
                    <div className="space-y-4">
                      <div className="space-y-2">
                        <Label htmlFor="city">Город</Label>
                        <Input
                          id="city"
                          value={settings.city}
                          onChange={(e) =>
                            setSettings({ ...settings, city: e.target.value })
                          }
                          placeholder="Москва"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="address">Адрес</Label>
                        <Textarea
                          id="address"
                          value={settings.address}
                          onChange={(e) =>
                            setSettings({ ...settings, address: e.target.value })
                          }
                          placeholder="Улица, дом, квартира"
                          rows={3}
                        />
                      </div>
                    </div>
                  </div>

                  <Separator />

                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold">Уведомления</h3>
                    <div className="flex items-center gap-3">
                      <input
                        type="checkbox"
                        id="newsletter"
                        checked={settings.subscribeToNewsletter}
                        onChange={(e) =>
                          setSettings({
                            ...settings,
                            subscribeToNewsletter: e.target.checked,
                          })
                        }
                        className="h-4 w-4"
                      />
                      <Label htmlFor="newsletter" className="cursor-pointer">
                        Подписаться на рассылку новинок, акций и промокодов
                      </Label>
                    </div>
                  </div>

                  <Separator />

                  <div className="flex flex-col sm:flex-row gap-3">
                    <Button
                      onClick={handleSaveSettings}
                      disabled={saving}
                      className="flex-1"
                      size="lg"
                    >
                      {saving ? 'Сохранение...' : 'Сохранить настройки'}
                    </Button>
                    <Button
                      variant="outline"
                      onClick={handleLogout}
                      className="flex-1"
                      size="lg"
                    >
                      <LogOut className="mr-2 h-5 w-5" />
                      Выйти из аккаунта
                    </Button>
                  </div>

                  <div className="pt-4 border-t">
                    <p className="text-xs text-muted-foreground">
                      Регистрируясь, вы соглашаетесь с{' '}
                      <a href="/privacy" className="underline hover:text-primary">
                        политикой конфиденциальности
                      </a>{' '}
                      и{' '}
                      <a href="/terms" className="underline hover:text-primary">
                        условиями использования
                      </a>
                    </p>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </main>
    </div>
  )
}

function OrderCard({
  order,
  getStatusColor,
  getStatusLabel,
  getStatusIcon,
  formatPrice,
  formatDate,
}: {
  order: Order
  getStatusColor: (status: string) => string
  getStatusLabel: (status: string) => string
  getStatusIcon: (status: string) => React.ReactNode
  formatPrice: (price: number) => string
  formatDate: (dateString: string) => string
}) {
  return (
    <Card>
      <CardContent className="p-6">
        <div className="space-y-4">
          {/* Header */}
          <div className="flex justify-between items-start gap-4">
            <div>
              <h3 className="font-semibold text-lg">{order.orderNumber}</h3>
              <p className="text-sm text-muted-foreground">
                {formatDate(order.createdAt)}
              </p>
            </div>
            <Badge className={`${getStatusColor(order.status)} flex items-center gap-2`}>
              {getStatusIcon(order.status)}
              {getStatusLabel(order.status)}
            </Badge>
          </div>

          {/* Items */}
          <div className="space-y-2">
            <p className="text-sm font-medium text-muted-foreground">
              Товары
            </p>
            <div className="space-y-2">
              {order.items.map((item) => (
                <div
                  key={item.id}
                  className="flex items-start gap-3 p-3 bg-muted/30 rounded-lg"
                >
                  <div className="relative h-12 w-12 flex-shrink-0 overflow-hidden rounded bg-muted">
                    {item.product.images.length > 0 ? (
                      <img
                        src={item.product.images[0].url}
                        alt={item.productName}
                        className="h-full w-full object-cover"
                      />
                    ) : (
                      <div className="h-full w-full flex items-center justify-center text-muted-foreground text-xs">
                        Фото
                      </div>
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <h4 className="font-medium text-sm">
                      {item.productName}
                    </h4>
                    <p className="text-xs text-muted-foreground">
                      Количество: {item.quantity}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="font-semibold">
                      {formatPrice(item.price * item.quantity)}
                    </p>
                  </div>
                </div>
              ))}
            </div>
            </div>

          {/* Delivery */}
          <div className="flex items-center gap-6 text-sm">
            <div className="flex items-center gap-2">
              <Truck className="h-4 w-4 text-muted-foreground" />
              <span className="text-muted-foreground">Доставка:</span>
            </div>
            <span className="font-medium">
              {order.deliveryMethod === 'cdek' ? 'СДЭК' : 'Курьер'}
            </span>
          </div>
          <div className="flex items-center gap-6 text-sm">
            <div className="flex items-center gap-2">
              <MapPin className="h-4 w-4 text-muted-foreground" />
              <span className="text-muted-foreground">Куда:</span>
            </div>
            <span className="font-medium">
              {order.city}
              {order.address && `, ${order.address}`}
            </span>
          </div>

          {/* Total */}
          <Separator />
          <div className="flex justify-between items-center">
            <span className="text-lg font-semibold">Итого:</span>
            <span className="text-2xl font-bold">
              {formatPrice(order.totalAmount)}
            </span>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
