'use client'

import { useState } from 'react'
import { Header } from '@/components/header'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Separator } from '@/components/ui/separator'
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group'
import { useCartStore, CartItem } from '@/store/cart'
import { useRouter } from 'next/navigation'
import { toast } from 'sonner'
import { Trash2, Truck, Package } from 'lucide-react'

const deliveryCosts = {
  cdek: 500,
  courier: 300,
}

export default function CheckoutPage() {
  const router = useRouter()
  const { items, updateQuantity, removeItem, getTotalPrice } = useCartStore()

  const [formData, setFormData] = useState({
    customerName: '',
    customerEmail: '',
    customerPhone: '',
    deliveryMethod: 'cdek' as 'cdek' | 'courier',
    city: '',
    address: '',
    promoCode: '',
    notes: '',
  })

  const [isSubmitting, setIsSubmitting] = useState(false)
  const [discount, setDiscount] = useState(0)
  const [validatingPromo, setValidatingPromo] = useState(false)
  const [promoValid, setPromoValid] = useState(false)
  const [promoMessage, setPromoMessage] = useState('')

  const deliveryCost = deliveryCosts[formData.deliveryMethod]
  const subtotal = getTotalPrice()
  const total = subtotal + deliveryCost - discount

  const handleInputChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    })
  }

  const handleDeliveryMethodChange = (value: string) => {
    setFormData({
      ...formData,
      deliveryMethod: value as 'cdek' | 'courier',
    })
  }

  const handleRemoveItem = (itemId: string) => {
    removeItem(itemId)
  }

  const handleQuantityChange = (itemId: string, quantity: number) => {
    updateQuantity(itemId, quantity)
  }

  const handleValidatePromo = async () => {
    if (!formData.promoCode.trim()) {
      setPromoMessage('')
      setPromoValid(false)
      setDiscount(0)
      return
    }

    setValidatingPromo(true)
    setPromoMessage('')
    setPromoValid(false)
    setDiscount(0)

    try {
      const response = await fetch(
        `/api/promocodes/validate?code=${encodeURIComponent(formData.promoCode)}&orderAmount=${subtotal}`
      )

      if (!response.ok) {
        const error = await response.json()
        setPromoMessage(error.error || 'Неверный промокод')
        setPromoValid(false)
        return
      }

      const data = await response.json()
      if (data.valid) {
        setPromoMessage('Промокод применён!')
        setPromoValid(true)
        setDiscount(data.discount)
      }
    } catch (error) {
      console.error('Error validating promo code:', error)
      setPromoMessage('Ошибка проверки промокода')
    } finally {
      setValidatingPromo(false)
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    try {
      const orderData = {
        customerName: formData.customerName,
        customerEmail: formData.customerEmail,
        customerPhone: formData.customerPhone,
        deliveryMethod: formData.deliveryMethod,
        deliveryCost,
        address: formData.deliveryMethod === 'cdek' ? formData.address : undefined,
        city: formData.city,
        promoCode: formData.promoCode || undefined,
        notes: formData.notes || undefined,
        items: items.map((item) => ({
          productId: item.productId,
          variantId: item.variantId,
          quantity: item.quantity,
        })),
      }

      const response = await fetch('/api/orders', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(orderData),
      })

      if (!response.ok) {
        const error = await response.json()
        throw new Error(error.error || 'Failed to create order')
      }

      const order = await response.json()

      // Clear cart
      useCartStore.getState().clearCart()

      toast.success('Заказ успешно оформлен!', {
        description: `Номер заказа: ${order.orderNumber}`,
      })

      // Redirect to home page
      router.push('/')
    } catch (error) {
      console.error('Error creating order:', error)
      toast.error('Ошибка при оформлении заказа', {
        description: error instanceof Error ? error.message : 'Попробуйте позже',
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  if (items.length === 0) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        <main className="flex-1 flex items-center justify-center">
          <Card className="max-w-md w-full mx-4">
            <CardHeader>
              <CardTitle>Корзина пуста</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground mb-4">
                Добавьте товары в корзину для оформления заказа
              </p>
              <Button onClick={() => router.push('/')} className="w-full">
                Перейти в каталог
              </Button>
            </CardContent>
          </Card>
        </main>
      </div>
    )
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Header />

      <main className="flex-1 py-8 px-4 md:px-8">
        <div className="container mx-auto max-w-6xl">
          <h1 className="text-3xl font-bold mb-8">Оформление заказа</h1>

          <form onSubmit={handleSubmit}>
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              {/* Left Column - Form */}
              <div className="lg:col-span-2 space-y-6">
                {/* Contact Information */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Package className="h-5 w-5" />
                      Контактная информация
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="customerName">Имя *</Label>
                        <Input
                          id="customerName"
                          name="customerName"
                          value={formData.customerName}
                          onChange={handleInputChange}
                          required
                          placeholder="Иван Иванов"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="customerPhone">Телефон *</Label>
                        <Input
                          id="customerPhone"
                          name="customerPhone"
                          value={formData.customerPhone}
                          onChange={handleInputChange}
                          required
                          placeholder="+7 (999) 999-99-99"
                        />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="customerEmail">Email *</Label>
                      <Input
                        id="customerEmail"
                        name="customerEmail"
                        type="email"
                        value={formData.customerEmail}
                        onChange={handleInputChange}
                        required
                        placeholder="example@mail.ru"
                      />
                    </div>
                  </CardContent>
                </Card>

                {/* Delivery Method */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Truck className="h-5 w-5" />
                      Способ доставки
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <RadioGroup
                      value={formData.deliveryMethod}
                      onValueChange={handleDeliveryMethodChange}
                    >
                      <div className="flex items-start space-x-3 p-4 border rounded-lg hover:bg-accent/50 cursor-pointer">
                        <RadioGroupItem value="cdek" id="cdek" />
                        <div className="flex-1">
                          <Label htmlFor="cdek" className="cursor-pointer font-medium">
                            СДЭК (по всей России)
                          </Label>
                          <p className="text-sm text-muted-foreground mt-1">
                            Доставка 5-7 рабочих дней — {deliveryCosts.cdek} ₽
                          </p>
                        </div>
                      </div>

                      <div className="flex items-start space-x-3 p-4 border rounded-lg hover:bg-accent/50 cursor-pointer">
                        <RadioGroupItem value="courier" id="courier" />
                        <div className="flex-1">
                          <Label htmlFor="courier" className="cursor-pointer font-medium">
                            Курьер (в городе производства)
                          </Label>
                          <p className="text-sm text-muted-foreground mt-1">
                            Доставка 1-2 дня — {deliveryCosts.courier} ₽
                          </p>
                        </div>
                      </div>
                    </RadioGroup>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-4">
                      <div className="space-y-2">
                        <Label htmlFor="city">Город *</Label>
                        <Input
                          id="city"
                          name="city"
                          value={formData.city}
                          onChange={handleInputChange}
                          required
                          placeholder="Москва"
                        />
                      </div>
                      {formData.deliveryMethod === 'cdek' && (
                        <div className="space-y-2">
                          <Label htmlFor="address">Адрес *</Label>
                          <Input
                            id="address"
                            name="address"
                            value={formData.address}
                            onChange={handleInputChange}
                            required
                            placeholder="Улица, дом, квартира"
                          />
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>

                {/* Promo Code */}
                <Card>
                  <CardHeader>
                    <CardTitle>Промокод</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="flex gap-2">
                      <Input
                        name="promoCode"
                        value={formData.promoCode}
                        onChange={handleInputChange}
                        placeholder="Введите промокод"
                        className="uppercase"
                      />
                      <Button
                        type="button"
                        variant="outline"
                        onClick={handleValidatePromo}
                        disabled={validatingPromo || !formData.promoCode.trim()}
                      >
                        {validatingPromo ? 'Проверка...' : 'Применить'}
                      </Button>
                    </div>
                    {promoMessage && (
                      <p className={`text-sm mt-2 ${promoValid ? 'text-green-600' : 'text-red-600'}`}>
                        {promoMessage}
                      </p>
                    )}
                  </CardContent>
                </Card>

                {/* Notes */}
                <Card>
                  <CardHeader>
                    <CardTitle>Комментарий к заказу</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <Textarea
                      name="notes"
                      value={formData.notes}
                      onChange={handleInputChange}
                      placeholder="Укажите пожелания к заказу..."
                      rows={3}
                    />
                  </CardContent>
                </Card>
              </div>

              {/* Right Column - Order Summary */}
              <div className="lg:col-span-1">
                <Card className="sticky top-20">
                  <CardHeader>
                    <CardTitle>Ваш заказ</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {/* Cart Items */}
                    <div className="space-y-3 max-h-64 overflow-y-auto">
                      {items.map((item) => (
                        <OrderItem
                          key={item.id}
                          item={item}
                          onRemove={handleRemoveItem}
                          onQuantityChange={handleQuantityChange}
                        />
                      ))}
                    </div>

                    <Separator />

                    {/* Price Breakdown */}
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Товары:</span>
                        <span>{subtotal.toFixed(2)} ₽</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Доставка:</span>
                        <span>{deliveryCost.toFixed(2)} ₽</span>
                      </div>
                      {discount > 0 && (
                        <div className="flex justify-between text-sm text-green-600">
                          <span>Скидка:</span>
                          <span>-{discount.toFixed(2)} ₽</span>
                        </div>
                      )}
                      <Separator />
                      <div className="flex justify-between text-lg font-bold">
                        <span>Итого:</span>
                        <span>{total.toFixed(2)} ₽</span>
                      </div>
                    </div>

                    <Separator />

                    {/* Submit Button */}
                    <Button
                      type="submit"
                      className="w-full"
                      size="lg"
                      disabled={isSubmitting}
                    >
                      {isSubmitting ? 'Оформление...' : 'Оформить заказ'}
                    </Button>

                    <p className="text-xs text-center text-muted-foreground">
                      Нажимая кнопку, вы соглашаетесь с{' '}
                      <a href="/privacy" className="underline hover:text-primary">
                        политикой конфиденциальности
                      </a>
                    </p>
                  </CardContent>
                </Card>
              </div>
            </div>
          </form>
        </div>
      </main>
    </div>
  )
}

function OrderItem({
  item,
  onRemove,
  onQuantityChange,
}: {
  item: CartItem
  onRemove: (id: string) => void
  onQuantityChange: (id: string, quantity: number) => void
}) {
  return (
    <div className="flex gap-3 p-3 bg-muted/30 rounded-lg">
      <div className="relative h-16 w-16 flex-shrink-0 overflow-hidden rounded border">
        <img
          src={item.productImage}
          alt={item.productName}
          className="h-full w-full object-cover"
        />
      </div>

      <div className="flex-1 min-w-0">
        <h4 className="font-medium text-sm line-clamp-2">{item.productName}</h4>
        <p className="text-xs text-muted-foreground">
          {item.variantSize && `${item.variantSize}`}
          {item.variantSize && item.variantColor && ', '}
          {item.variantColor && `${item.variantColor}`}
        </p>
        <div className="flex items-center justify-between mt-2">
          <div className="flex items-center gap-1">
            <button
              type="button"
              onClick={() => onQuantityChange(item.id, item.quantity - 1)}
              className="w-6 h-6 rounded border flex items-center justify-center hover:bg-accent text-xs"
            >
              -
            </button>
            <span className="text-sm w-6 text-center">{item.quantity}</span>
            <button
              type="button"
              onClick={() => onQuantityChange(item.id, item.quantity + 1)}
              className="w-6 h-6 rounded border flex items-center justify-center hover:bg-accent text-xs"
            >
              +
            </button>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-sm font-semibold">
              {(item.productPrice * item.quantity).toFixed(2)} ₽
            </span>
            <button
              type="button"
              onClick={() => onRemove(item.id)}
              className="text-muted-foreground hover:text-destructive"
            >
              <Trash2 className="h-4 w-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}
