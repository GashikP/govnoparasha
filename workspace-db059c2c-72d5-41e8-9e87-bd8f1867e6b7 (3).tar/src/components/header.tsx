'use client'

import Link from 'next/link'
import { ShoppingBag, Menu, User as UserIcon } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet'
import { useCartStore } from '@/store/cart'
import { useAuthStore } from '@/store/auth'
import { CartSheet } from './cart-sheet'
import { ThemeToggle } from './theme-toggle'
import { AuthDialog } from './auth-dialog'

export function Header() {
  const totalItems = useCartStore((state) => state.getTotalItems())
  const { user } = useAuthStore()

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-16 items-center justify-between px-4 md:px-8">
        {/* Logo */}
        <Link href="/" className="flex items-center space-x-2">
          <span className="text-2xl font-bold bg-gradient-to-r from-pink-500 via-purple-500 to-teal-500 bg-clip-text text-transparent dark:from-pink-400 dark:via-purple-400 dark:to-teal-400">
            Pshish
          </span>
        </Link>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center space-x-6">
          <Link href="/" className="text-sm font-medium transition-colors hover:text-primary">
            Главная
          </Link>
          <Link href="#catalog" className="text-sm font-medium transition-colors hover:text-primary">
            Каталог
          </Link>
          <Link href="#about" className="text-sm font-medium transition-colors hover:text-primary">
            О нас
          </Link>
          <Link href="/blog" className="text-sm font-medium transition-colors hover:text-primary">
            Блог
          </Link>
          <Link href="#contacts" className="text-sm font-medium transition-colors hover:text-primary">
            Контакты
          </Link>
        </nav>

        {/* Cart & Mobile Menu */}
        <div className="flex items-center space-x-2">
          <ThemeToggle />

          <CartSheet>
            <Button variant="ghost" size="icon" className="relative">
              <ShoppingBag className="h-5 w-5" />
              {totalItems > 0 && (
                <span className="absolute -top-1 -right-1 flex h-5 w-5 items-center justify-center rounded-full bg-primary text-xs text-primary-foreground">
                  {totalItems}
                </span>
              )}
            </Button>
          </CartSheet>

          {user ? (
            <Button variant="ghost" size="icon" asChild>
              <Link href="/profile">
                <UserIcon className="h-5 w-5" />
              </Link>
            </Button>
          ) : (
            <AuthDialog>
              <Button variant="ghost" size="icon">
                <UserIcon className="h-5 w-5" />
              </Button>
            </AuthDialog>
          )}

          <Sheet>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" className="md:hidden">
                <Menu className="h-5 w-5" />
              </Button>
            </SheetTrigger>
            <SheetContent side="right">
              <nav className="flex flex-col space-y-4 mt-8">
                <Link href="/" className="text-lg font-medium transition-colors hover:text-primary">
                  Главная
                </Link>
                <Link href="#catalog" className="text-lg font-medium transition-colors hover:text-primary">
                  Каталог
                </Link>
                <Link href="#about" className="text-lg font-medium transition-colors hover:text-primary">
                  О нас
                </Link>
                <Link href="/blog" className="text-lg font-medium transition-colors hover:text-primary">
                  Блог
                </Link>
                <Link href="#contacts" className="text-lg font-medium transition-colors hover:text-primary">
                  Контакты
                </Link>
                {user ? (
                  <Link href="/profile" className="text-lg font-medium transition-colors hover:text-primary">
                    Личный кабинет
                  </Link>
                ) : (
                  <AuthDialog>
                    <Button variant="outline" className="w-full">
                      Войти
                    </Button>
                  </AuthDialog>
                )}
              </nav>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </header>
  )
}
