'use client'

import { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Textarea } from '@/components/ui/textarea'
import { Label } from '@/components/ui/label'
import { Star, StarHalf } from 'lucide-react'
import { useAuthStore } from '@/store/auth'
import { toast } from 'sonner'

interface Review {
  id: string
  author: string
  rating: number
  text?: string
  createdAt: string
  user?: {
    name?: string
  }
}

interface ProductReviewsProps {
  productId: string
  reviews: Review[]
}

export function ProductReviews({ productId, reviews: initialReviews }: ProductReviewsProps) {
  const { user } = useAuthStore()
  const [reviews, setReviews] = useState<Review[]>(initialReviews)
  const [showForm, setShowForm] = useState(false)
  const [submitting, setSubmitting] = useState(false)
  const [formData, setFormData] = useState({
    rating: 5,
    text: '',
  })

  const averageRating = reviews.length > 0
    ? reviews.reduce((sum, r) => sum + r.rating, 0) / reviews.length
    : 0

  const ratingDistribution = [5, 4, 3, 2, 1].map((rating) => ({
    rating,
    count: reviews.filter((r) => r.rating === rating).length,
  }))

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setSubmitting(true)

    try {
      const response = await fetch('/api/reviews', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          productId,
          userId: user?.id,
          author: user?.name || user?.email || 'Аноним',
          rating: formData.rating,
          text: formData.text,
        }),
      })

      if (!response.ok) {
        throw new Error('Failed to submit review')
      }

      const newReview = await response.json()
      setReviews([newReview, ...reviews])
      setShowForm(false)
      setFormData({ rating: 5, text: '' })
      toast.success('Отзыв отправлен!')
    } catch (error) {
      console.error('Error submitting review:', error)
      toast.error('Ошибка отправки отзыва')
    } finally {
      setSubmitting(false)
    }
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('ru-RU', {
      day: 'numeric',
      month: 'long',
      year: 'numeric',
    })
  }

  const renderStars = (rating: number) => {
    const stars = []
    for (let i = 1; i <= 5; i++) {
      if (rating >= i) {
        stars.push(<Star key={i} className="h-4 w-4 fill-current" />)
      } else if (rating >= i - 0.5) {
        stars.push(<StarHalf key={i} className="h-4 w-4 fill-current" />)
      } else {
        stars.push(<Star key={i} className="h-4 w-4" />)
      }
    }
    return stars
  }

  return (
    <div className="space-y-6">
      {/* Rating Summary */}
      <Card>
        <CardHeader>
          <CardTitle>Отзывы и оценки</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Average Rating */}
            <div className="flex items-center gap-6">
              <div className="text-center">
                <div className="text-5xl font-bold">
                  {averageRating.toFixed(1)}
                </div>
                <div className="text-sm text-muted-foreground">
                  {reviews.length} {reviews.length === 1 ? 'отзыв' : 'отзывов'}
                </div>
              </div>
              <div className="flex flex-col gap-1">
                {renderStars(averageRating)}
              </div>
            </div>

            {/* Rating Distribution */}
            <div className="space-y-2">
              {ratingDistribution.map(({ rating, count }) => (
                <div key={rating} className="flex items-center gap-2 text-sm">
                  <span className="w-8">{rating}</span>
                  <div className="flex-1 h-2 bg-muted rounded-full overflow-hidden">
                    <div
                      className="h-full bg-primary"
                      style={{
                        width: reviews.length > 0
                          ? `${(count / reviews.length) * 100}%`
                          : '0%',
                      }}
                    />
                  </div>
                  <span className="w-8 text-right">{count}</span>
                </div>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Write Review Button */}
      {!showForm && (
        <Button onClick={() => setShowForm(true)} className="w-full md:w-auto">
          Написать отзыв
        </Button>
      )}

      {/* Review Form */}
      {showForm && (
        <Card>
          <CardHeader>
            <CardTitle>Написать отзыв</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label>Ваша оценка</Label>
                <div className="flex gap-1">
                  {[1, 2, 3, 4, 5].map((rating) => (
                    <button
                      key={rating}
                      type="button"
                      onClick={() =>
                        setFormData({ ...formData, rating })
                      }
                      className="p-1 hover:bg-accent rounded transition-colors"
                    >
                      <Star
                        className={`h-6 w-6 ${
                          rating <= formData.rating
                            ? 'fill-yellow-400 text-yellow-400'
                            : ''
                        }`}
                      />
                    </button>
                  ))}
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="text">Ваш отзыв</Label>
                <Textarea
                  id="text"
                  value={formData.text}
                  onChange={(e) =>
                    setFormData({ ...formData, text: e.target.value })
                  }
                  placeholder="Расскажите о вашем опыте использования товара..."
                  rows={5}
                  maxLength={1000}
                />
                <p className="text-xs text-muted-foreground">
                  Минимум 10 символов, максимум 1000
                </p>
              </div>

              <div className="flex gap-2">
                <Button type="submit" disabled={submitting}>
                  {submitting ? 'Отправка...' : 'Отправить отзыв'}
                </Button>
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setShowForm(false)}
                >
                  Отмена
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      )}

      {/* Reviews List */}
      <div className="space-y-4">
        {reviews.length === 0 ? (
          <Card>
            <CardContent className="py-12 text-center text-muted-foreground">
              Отзывов пока нет. Будьте первым!
            </CardContent>
          </Card>
        ) : (
          reviews.map((review) => (
            <Card key={review.id}>
              <CardContent className="pt-6">
                <div className="flex items-start justify-between mb-3">
                  <div>
                    <div className="font-semibold">{review.author}</div>
                    <div className="text-sm text-muted-foreground">
                      {formatDate(review.createdAt)}
                    </div>
                  </div>
                  <div className="flex gap-0.5">
                    {renderStars(review.rating)}
                  </div>
                </div>

                {review.text && (
                  <p className="text-muted-foreground leading-relaxed">
                    {review.text}
                  </p>
                )}
              </CardContent>
            </Card>
          ))
        )}
      </div>
    </div>
  )
}
