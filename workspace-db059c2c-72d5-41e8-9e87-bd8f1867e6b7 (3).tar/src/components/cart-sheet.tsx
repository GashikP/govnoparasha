'use client'

import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetFooter,
} from '@/components/ui/sheet'
import { Button } from '@/components/ui/button'
import { Separator } from '@/components/ui/separator'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Minus, Plus, Trash2 } from 'lucide-react'
import { useCartStore, CartItem } from '@/store/cart'
import { useState } from 'react'
import { useRouter } from 'next/navigation'

interface CartSheetProps {
  children: React.ReactNode
  open?: boolean
  onOpenChange?: (open: boolean) => void
}

export function CartSheet({ children, open, onOpenChange }: CartSheetProps) {
  const [isOpen, setIsOpen] = useState(false)
  const router = useRouter()
  const { items, updateQuantity, removeItem, clearCart, getTotalPrice } =
    useCartStore()

  const handleOpenChange = (open: boolean) => {
    setIsOpen(open)
    onOpenChange?.(open)
  }

  const total = getTotalPrice()

  const handleCheckout = () => {
    handleOpenChange(false)
    router.push('/checkout')
  }

  return (
    <Sheet open={open ?? isOpen} onOpenChange={handleOpenChange}>
      {children}
      <SheetContent className="flex w-full flex-col sm:max-w-lg">
        <SheetHeader>
          <SheetTitle>Корзина</SheetTitle>
        </SheetHeader>

        {items.length === 0 ? (
          <div className="flex flex-1 flex-col items-center justify-center space-y-4">
            <p className="text-muted-foreground">Ваша корзина пуста</p>
            <Button variant="outline" onClick={() => handleOpenChange(false)}>
              Продолжить покупки
            </Button>
          </div>
        ) : (
          <>
            <ScrollArea className="flex-1 -mx-6 px-6">
              <div className="space-y-4 py-4">
                {items.map((item) => (
                  <CartItem key={item.id} item={item} />
                ))}
              </div>
            </ScrollArea>

            <Separator className="my-4" />

            <SheetFooter className="flex-col items-stretch sm:items-start sm:flex-col">
              <div className="flex items-center justify-between py-2">
                <span className="font-medium">Итого:</span>
                <span className="text-2xl font-bold">{total.toFixed(2)} ₽</span>
              </div>

              <div className="flex flex-col space-y-2">
                <Button
                  size="lg"
                  className="w-full"
                  onClick={handleCheckout}
                >
                  Оформить заказ
                </Button>
                <Button
                  variant="outline"
                  size="lg"
                  className="w-full"
                  onClick={() => clearCart()}
                >
                  Очистить корзину
                </Button>
              </div>
            </SheetFooter>
          </>
        )}
      </SheetContent>
    </Sheet>
  )
}

function CartItem({ item }: { item: CartItem }) {
  const { updateQuantity, removeItem } = useCartStore()

  return (
    <div className="flex gap-4">
      <div className="relative h-24 w-24 overflow-hidden rounded-lg border">
        <img
          src={item.productImage}
          alt={item.productName}
          className="h-full w-full object-cover"
        />
      </div>

      <div className="flex flex-1 flex-col space-y-2">
        <div className="flex justify-between">
          <div>
            <h4 className="font-medium">{item.productName}</h4>
            <p className="text-sm text-muted-foreground">
              {item.variantSize && `Размер: ${item.variantSize}`}
              {item.variantSize && item.variantColor && ', '}
              {item.variantColor && `Цвет: ${item.variantColor}`}
            </p>
          </div>
          <Button
            variant="ghost"
            size="icon"
            className="h-8 w-8 text-muted-foreground hover:text-destructive"
            onClick={() => removeItem(item.id)}
          >
            <Trash2 className="h-4 w-4" />
          </Button>
        </div>

        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Button
              variant="outline"
              size="icon"
              className="h-8 w-8"
              onClick={() => updateQuantity(item.id, item.quantity - 1)}
            >
              <Minus className="h-4 w-4" />
            </Button>
            <span className="w-8 text-center">{item.quantity}</span>
            <Button
              variant="outline"
              size="icon"
              className="h-8 w-8"
              onClick={() => updateQuantity(item.id, item.quantity + 1)}
            >
              <Plus className="h-4 w-4" />
            </Button>
          </div>

          <span className="font-bold">
            {(item.productPrice * item.quantity).toFixed(2)} ₽
          </span>
        </div>
      </div>
    </div>
  )
}
