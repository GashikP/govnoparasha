'use client'

import Link from 'next/link'
import Image from 'next/image'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardFooter } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { ShoppingCart } from 'lucide-react'
import { useCartStore } from '@/store/cart'
import { toast } from 'sonner'

export interface Product {
  id: string
  name: string
  slug: string
  description?: string
  price: number
  oldPrice?: number
  style: 'dark' | 'cute' | 'marine' | 'normal'
  imageUrl: string
  category: string
  variants: {
    id: string
    size?: string
    color?: string
    stock: number
  }[]
}

interface ProductCardProps {
  product: Product
}

const styleLabels = {
  dark: 'Мрачный',
  cute: 'Милый',
  marine: 'Морской',
  normal: 'Обычный',
}

const styleColors = {
  dark: 'bg-slate-700 text-slate-100',
  cute: 'bg-pink-100 text-pink-700',
  marine: 'bg-cyan-100 text-cyan-700',
  normal: 'bg-stone-100 text-stone-700',
}

export function ProductCard({ product }: ProductCardProps) {
  const { addItem } = useCartStore()

  const variant = product.variants[0]

  const handleAddToCart = (e: React.MouseEvent) => {
    e.preventDefault()
    e.stopPropagation()

    if (!variant) return

    addItem({
      productId: product.id,
      productName: product.name,
      productImage: product.imageUrl,
      productPrice: product.price,
      variantId: variant.id,
      variantSize: variant.size,
      variantColor: variant.color,
      quantity: 1,
    })

    toast.success('Товар добавлен в корзину!')
  }

  return (
    <Link href={`/product/${product.id}`} className="block">
      <Card className="group overflow-hidden transition-all hover:shadow-lg h-full flex flex-col">
        <div className="relative aspect-square overflow-hidden">
          <Image
            src={product.imageUrl}
            alt={product.name}
            fill
            className="object-cover transition-transform group-hover:scale-105"
          />
          <Badge
            className={`absolute top-2 right-2 ${styleColors[product.style]}`}
          >
            {styleLabels[product.style]}
          </Badge>
          {product.oldPrice && (
            <Badge className="absolute top-2 left-2 bg-red-500">
              -
              {Math.round(
                ((product.oldPrice - product.price) / product.oldPrice) * 100
              )}
              %
            </Badge>
          )}
        </div>

        <CardContent className="p-4 flex-1 flex flex-col">
          <h3 className="font-semibold mb-2 line-clamp-2 hover:text-primary transition-colors">
            {product.name}
          </h3>
          <p className="text-sm text-muted-foreground mb-2">{product.category}</p>
          <div className="mt-auto flex items-center gap-2">
            <span className="text-xl font-bold">{product.price.toFixed(2)} ₽</span>
            {product.oldPrice && (
              <span className="text-sm text-muted-foreground line-through">
                {product.oldPrice.toFixed(2)} ₽
              </span>
            )}
          </div>
        </CardContent>

        <CardFooter className="p-4 pt-0">
          <Button
            className="w-full"
            onClick={handleAddToCart}
            disabled={!variant || variant.stock === 0}
          >
            <ShoppingCart className="mr-2 h-4 w-4" />
            {variant && variant.stock > 0 ? 'В корзину' : 'Нет в наличии'}
          </Button>
        </CardFooter>
      </Card>
    </Link>
  )
}
